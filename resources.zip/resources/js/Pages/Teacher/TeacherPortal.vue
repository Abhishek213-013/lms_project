<template>
  <div class="min-h-screen bg-gray-50 flex">
    <!-- Sidebar -->
    <TeacherSidebar 
      @showUploadModal="showUploadModal = true"
      @createAssignment="createAssignment"
      @goBackToAdmin="goBackToAdmin"
    />

    <!-- Main Content -->
    <div class="flex-1 ml-64 min-w-0">
      <!-- Top Navbar -->
      <nav class="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div class="px-6 py-4">
          <div class="flex justify-between items-center">
            <div class="flex items-center min-w-0">
              <h1 class="custom-heading truncate">Teacher Portal - {{ teacher.name || 'Loading...' }}</h1>
            </div>
            
            <div class="flex items-center space-x-4 flex-shrink-0">
              <!-- Search -->
              <div class="relative hidden md:block">
                <input 
                  type="text" 
                  placeholder="Search..." 
                  class="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent w-64"
                >
                <svg class="w-5 h-5 text-gray-400 absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                </svg>
              </div>
              

              <!-- User Menu -->
              <div class="relative flex-shrink-0">
                <button 
                  @click="toggleUserMenu"
                  class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-100 min-w-0"
                >
                  <div class="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center flex-shrink-0 overflow-hidden">
                    <img 
                      v-if="teacher.profile_picture_url" 
                      :src="teacher.profile_picture_url" 
                      :alt="teacher.name"
                      class="w-full h-full object-cover"
                    >
                    <span v-else class="text-white text-sm font-semibold">{{ userInitials }}</span>
                  </div>
                  <svg class="w-4 h-4 text-gray-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </button>

                <!-- User Dropdown -->
                <div v-show="userMenuOpen" class="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-20">
                  <!-- User Info in Dropdown Header -->
                  <div class="px-4 py-3 border-b border-gray-200">
                    <div class="flex items-center space-x-3">
                      <div class="w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center overflow-hidden">
                        <img 
                          v-if="teacher.profile_picture_url" 
                          :src="teacher.profile_picture_url" 
                          :alt="teacher.name"
                          class="w-full h-full object-cover"
                        >
                        <span v-else class="text-white text-sm font-semibold">{{ userInitials }}</span>
                      </div>
                      <div class="text-left min-w-0">
                        <p class="text-sm font-medium text-gray-700 truncate">{{ teacher.name || 'Teacher' }}</p>
                        <p class="text-xs text-gray-500 capitalize truncate">Teacher</p>
                      </div>
                    </div>
                  </div>
                  
                  <!-- Dropdown Menu Items -->
                  <a href="#" class="px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center" @click="editProfile">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                    </svg>
                    Profile
                  </a>
                  <a href="#" class="px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center" @click="navigateToSettings">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path>
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                    </svg>
                    Settings
                  </a>
                  <div class="border-t border-gray-200 my-1"></div>
                  <button 
                    @click="logout"
                    class="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-100 flex items-center"
                  >
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                    </svg>
                    Sign out
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <!-- Page Content -->
      <div class="p-6 max-w-full overflow-x-hidden">
        <!-- Main Content -->
        <div class="space-y-6">
          <!-- Teacher Profile Header -->
          <div class="bg-white rounded-lg border border-gray-200 p-6">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between">
              <div class="flex items-center space-x-4 mb-4 md:mb-0">
                <!-- Profile Picture with Upload Functionality -->
                <div class="relative group">
                  <div class="w-20 h-20 bg-purple-600 rounded-full flex items-center justify-center overflow-hidden cursor-pointer"
                       @click="triggerProfilePictureUpload">
                    <img 
                      v-if="teacher.profile_picture_url" 
                      :src="teacher.profile_picture_url" 
                      :alt="teacher.name"
                      class="w-full h-full object-cover"
                    >
                    <span v-else class="text-white text-2xl font-semibold">
                      {{ getUserInitials(teacher.name) }}
                    </span>
                    
                    <!-- Upload Overlay -->
                    <div class="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                      <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"></path>
                      </svg>
                    </div>
                  </div>
                  
                  <!-- Remove Picture Button (only shown when picture exists) -->
                  <button 
                    v-if="teacher.profile_picture_url"
                    @click.stop="removeProfilePicture"
                    class="absolute -top-1 -right-1 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center text-xs hover:bg-red-600 transition-colors shadow-md"
                    title="Remove profile picture"
                  >
                    ×
                  </button>

                  <!-- Upload Indicator -->
                  <div v-if="uploadingPicture" class="absolute inset-0 bg-black bg-opacity-70 rounded-full flex items-center justify-center">
                    <svg class="animate-spin w-6 h-6 text-white" fill="none" viewBox="0 0 24 24">
                      <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                      <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  </div>
                </div>
                
                <div>
                  <h2 class="text-2xl font-bold text-gray-900">{{ teacher.name }}</h2>
                  <p class="text-gray-600">{{ teacher.email }}</p>
                  <p class="text-sm text-gray-500">@{{ teacher.username }}</p>
                </div>
              </div>
              <div class="flex space-x-3">
                <button 
                  @click="editProfile"
                  class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Edit Profile
                </button>
                <button 
                  @click="sendMessage"
                  class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Message
                </button>
              </div>
            </div>
          </div>

          <!-- Stats Cards -->
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div class="bg-white rounded-lg border border-gray-200 p-6">
              <div class="flex justify-between items-start">
                <div>
                  <p class="text-sm font-medium text-gray-600 mb-2">Total Classes</p>
                  <h3 class="text-3xl font-bold text-blue-600">{{ teacherClasses.length }}</h3>
                </div>
                <div class="p-3 bg-blue-100 rounded-lg">
                  <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                  </svg>
                </div>
              </div>
            </div>

            <div class="bg-white rounded-lg border border-gray-200 p-6">
              <div class="flex justify-between items-start">
                <div>
                  <p class="text-sm font-medium text-gray-600 mb-2">Total Students</p>
                  <h3 class="text-3xl font-bold text-green-600">{{ totalStudents }}</h3>
                </div>
                <div class="p-3 bg-green-100 rounded-lg">
                  <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                  </svg>
                </div>
              </div>
            </div>

            <div class="bg-white rounded-lg border border-gray-200 p-6">
              <div class="flex justify-between items-start">
                <div>
                  <p class="text-sm font-medium text-gray-600 mb-2">Resources</p>
                  <h3 class="text-3xl font-bold text-purple-600">{{ recentResources.length }}</h3>
                </div>
                <div class="p-3 bg-purple-100 rounded-lg">
                  <svg class="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                  </svg>
                </div>
              </div>
            </div>

            <!-- Experience Stats Card -->
            <div class="bg-white rounded-lg border border-gray-200 p-6">
              <div class="flex justify-between items-start">
                <div>
                  <p class="text-sm font-medium text-gray-600 mb-2">Experience</p>
                  <h3 class="text-3xl font-bold text-orange-600">
                    {{ formatExperience(teacher.experience) }}
                  </h3>
                  <p class="text-xs text-gray-500 mt-1">Teaching experience</p>
                </div>
                <div class="p-3 bg-orange-100 rounded-lg">
                  <svg class="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                  </svg>
                </div>
              </div>
            </div>
          </div>

          <!-- Main Content Grid -->
          <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Left Column - Teacher Info -->
            <div class="lg:col-span-1 space-y-6">
              <!-- Teacher Information -->
              <div class="bg-white rounded-lg border border-gray-200 p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Teacher Information</h3>
                <div class="space-y-4">
                  <div>
                    <label class="text-sm font-medium text-gray-600">Experience</label>
                    <p class="text-gray-900">{{ formatExperience(teacher.experience) }} of teaching experience</p>
                    <p class="text-xs text-gray-500 mt-1">
                      <span v-if="getExperienceLevel(teacher.experience)" 
                            :class="`px-2 py-1 rounded-full text-xs ${getExperienceLevel(teacher.experience).color}`">
                        {{ getExperienceLevel(teacher.experience).level }}
                      </span>
                    </p>
                  </div>
                  <div>
                    <label class="text-sm font-medium text-gray-600">Education</label>
                    <p class="text-gray-900">{{ teacher.education_qualification }} from {{ teacher.institute }}</p>
                  </div>
                  <div>
                    <label class="text-sm font-medium text-gray-600">Date of Birth</label>
                    <p class="text-gray-900">{{ formatDate(teacher.dob) }}</p>
                  </div>
                  <div>
                    <label class="text-sm font-medium text-gray-600">Join Date</label>
                    <p class="text-gray-900">{{ formatDate(teacher.created_at) }}</p>
                  </div>
                </div>
              </div>

              <!-- Quick Actions -->
              <div class="bg-white rounded-lg border border-gray-200 p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Quick Actions</h3>
                <div class="space-y-3">
                  <button 
                    @click="showUploadModal = true"
                    class="w-full flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-left"
                  >
                    <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                    </svg>
                    <span>Upload Resources</span>
                  </button>
                  <button 
                    @click="createAssignment"
                    class="w-full flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-left"
                  >
                    <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
                    </svg>
                    <span>Create Assignment</span>
                  </button>
                  <button 
                    @click="scheduleClass"
                    class="w-full flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-left"
                  >
                    <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                    </svg>
                    <span>Schedule Class</span>
                  </button>
                </div>
              </div>
            </div>

            <!-- Right Column - Classes and Resources -->
            <div class="lg:col-span-2 space-y-6">
              <!-- Classes Section -->
              <div class="bg-white rounded-lg border border-gray-200 p-6">
                <div class="flex justify-between items-center mb-4">
                  <h3 class="text-lg font-semibold text-gray-800">My Classes</h3>
                  <button class="text-blue-600 hover:text-blue-700 text-sm font-medium" @click="navigateToAllClasses">
                    View All
                  </button>
                </div>
                <div class="space-y-4">
                  <div 
                    v-for="classItem in teacherClasses" 
                    :key="classItem.id"
                    class="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                    @click="viewClass(classItem.id)"
                  >
                    <div class="flex justify-between items-start">
                      <div>
                        <h4 class="font-semibold text-gray-900">{{ classItem.name }}</h4>
                        <p class="text-sm text-gray-600">{{ classItem.subject }} • {{ classItem.studentCount }} students</p>
                        <p class="text-xs text-gray-500 mt-1">{{ classItem.schedule }}</p>
                      </div>
                      <span :class="`px-2 py-1 text-xs font-semibold rounded-full ${getClassStatusColor(classItem.status)}`">
                        {{ classItem.status }}
                      </span>
                    </div>
                  </div>
                  <div v-if="teacherClasses.length === 0" class="text-center py-8 text-gray-500">
                    No classes assigned yet.
                  </div>
                </div>
              </div>

              <!-- Recent Resources -->
              <div class="bg-white rounded-lg border border-gray-200 p-6">
                <div class="flex justify-between items-center mb-4">
                  <h3 class="text-lg font-semibold text-gray-800">Recent Resources</h3>
                  <button class="text-blue-600 hover:text-blue-700 text-sm font-medium" @click="navigateToMyResources">
                    View All
                  </button>
                </div>
                <div class="space-y-3">
                  <div 
                    v-for="resource in recentResources" 
                    :key="resource.id"
                    class="flex items-center justify-between p-3 border border-gray-200 rounded-lg"
                  >
                    <div class="flex items-center space-x-3">
                      <div :class="`p-2 rounded-lg ${getResourceTypeColor(resource.type)}`">
                        <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path v-if="resource.type === 'video'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path>
                          <path v-else stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                        </svg>
                      </div>
                      <div>
                        <h4 class="text-sm font-medium text-gray-900">{{ resource.title }}</h4>
                        <p class="text-xs text-gray-500">{{ resource.class }} • {{ formatDate(resource.uploaded_at) }}</p>
                      </div>
                    </div>
                    <span class="text-xs text-gray-500 capitalize">{{ resource.type }}</span>
                  </div>
                  <div v-if="recentResources.length === 0" class="text-center py-8 text-gray-500">
                    No resources uploaded yet.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Profile Picture Upload Modal -->
  <div v-if="showProfilePictureModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
    <div class="bg-white rounded-lg w-full max-w-md mx-4">
      <div class="px-6 py-4 border-b border-gray-200">
        <h3 class="text-lg font-semibold text-gray-800">Upload Profile Picture</h3>
      </div>

      <div class="p-6">
        <!-- Image Preview -->
        <div v-if="profilePicturePreview" class="mb-4 flex justify-center">
          <div class="w-32 h-32 rounded-full overflow-hidden border-4 border-gray-200">
            <img :src="profilePicturePreview" alt="Preview" class="w-full h-full object-cover">
          </div>
        </div>

        <!-- Upload Area -->
        <div 
          @drop="handleDrop"
          @dragover="handleDragOver"
          @dragleave="handleDragLeave"
          :class="`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
            isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400'
          }`"
          @click="triggerFileInput"
        >
          <input 
            type="file" 
            ref="fileInput"
            @change="handleFileSelect"
            accept="image/jpeg,image/png,image/jpg,image/gif"
            class="hidden"
          >
          
          <svg class="w-12 h-12 text-gray-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
          </svg>
          
          <p class="text-gray-600 mb-2">
            <span class="text-blue-600 font-medium">Click to upload</span> or drag and drop
          </p>
          <p class="text-xs text-gray-500">
            PNG, JPG, GIF up to 2MB
          </p>
        </div>

        <!-- Error Message -->
        <div v-if="uploadError" class="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
          <p class="text-sm text-red-600">{{ uploadError }}</p>
        </div>

        <!-- Form Actions -->
        <div class="flex justify-end space-x-3 pt-4 border-t border-gray-200 mt-4">
          <button 
            type="button"
            @click="cancelProfilePictureUpload"
            class="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button 
            type="button"
            @click="uploadProfilePicture"
            :disabled="!selectedFile || uploadingPicture"
            class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center"
          >
            <svg v-if="uploadingPicture" class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
              <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
              <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            {{ uploadingPicture ? 'Uploading...' : 'Upload Picture' }}
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- Upload Resource Modal -->
  <div v-if="showUploadModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
    <div class="bg-white rounded-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto mx-4">
      <div class="px-6 py-4 border-b border-gray-200">
        <h3 class="text-lg font-semibold text-gray-800">Upload Resource</h3>
      </div>

      <form @submit.prevent="uploadResource" class="p-6 space-y-4">
        <!-- Resource Type -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Resource Type *</label>
          <select 
            v-model="newResource.type"
            required
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Select type</option>
            <option value="video">Video Link</option>
            <option value="pdf">PDF Document</option>
            <option value="document">Other Document</option>
            <option value="link">External Link</option>
          </select>
        </div>

        <!-- Resource Title -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Title *</label>
          <input 
            v-model="newResource.title"
            type="text" 
            required
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Enter resource title"
          >
        </div>

        <!-- Resource Description -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Description</label>
          <textarea 
            v-model="newResource.description"
            rows="3"
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Enter resource description"
          ></textarea>
        </div>

        <!-- Resource Content based on type -->
        <div v-if="newResource.type === 'video'">
          <label class="block text-sm font-medium text-gray-700 mb-2">Video URL *</label>
          <input 
            v-model="newResource.content"
            type="url" 
            required
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="https://www.youtube.com/watch?v=..."
          >
        </div>

        <div v-else-if="newResource.type === 'pdf' || newResource.type === 'document'">
          <label class="block text-sm font-medium text-gray-700 mb-2">Upload File *</label>
          <input 
            type="file"
            @change="handleFileUpload"
            accept=".pdf,.doc,.docx,.txt"
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
        </div>

        <div v-else-if="newResource.type === 'link'">
          <label class="block text-sm font-medium text-gray-700 mb-2">Link URL *</label>
          <input 
            v-model="newResource.content"
            type="url" 
            required
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="https://example.com"
          >
        </div>

        <!-- Assigned Class -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Assign to Class</label>
          <select 
            v-model="newResource.assigned_class"
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">All Classes</option>
            <option v-for="classItem in teacherClasses" :key="classItem.id" :value="classItem.id">
              {{ classItem.name }}
            </option>
          </select>
        </div>

        <!-- Form Actions -->
        <div class="flex justify-end space-x-3 pt-4 border-t border-gray-200">
          <button 
            type="button"
            @click="showUploadModal = false"
            class="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button 
            type="submit"
            :disabled="uploading"
            class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            {{ uploading ? 'Uploading...' : 'Upload Resource' }}
          </button>
        </div>
      </form>
    </div>
  </div>

  <!-- Edit Profile Modal -->
  <div v-if="showEditProfileModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
    <div class="bg-white rounded-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto mx-4">
      <div class="px-6 py-4 border-b border-gray-200">
        <h3 class="text-lg font-semibold text-gray-800">Edit Profile</h3>
      </div>

      <form @submit.prevent="saveProfile" class="p-6 space-y-4">
        <!-- Profile Picture in Edit Modal -->
        <div class="flex items-center space-x-4">
          <div class="relative">
            <div class="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center overflow-hidden">
              <img 
                v-if="teacher.profile_picture_url" 
                :src="teacher.profile_picture_url" 
                :alt="teacher.name"
                class="w-full h-full object-cover"
              >
              <span v-else class="text-white text-lg font-semibold">
                {{ getUserInitials(teacher.name) }}
              </span>
            </div>
          </div>
          <div>
            <p class="text-sm text-gray-600">Profile Picture</p>
            <button 
              type="button"
              @click="triggerProfilePictureUploadFromEdit"
              class="text-sm text-blue-600 hover:text-blue-700"
            >
              Change picture
            </button>
          </div>
        </div>

        <!-- Name -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
          <input 
            v-model="profileForm.name"
            type="text" 
            required
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Enter your full name"
            :disabled="savingProfile"
          >
        </div>

        <!-- Email -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Email *</label>
          <input 
            v-model="profileForm.email"
            type="email" 
            required
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Enter your email"
            :disabled="savingProfile"
          >
        </div>

        <!-- Username -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Username *</label>
          <input 
            v-model="profileForm.username"
            type="text" 
            required
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Enter your username"
            :disabled="savingProfile"
          >
        </div>

        <!-- Date of Birth -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Date of Birth *</label>
          <input 
            v-model="profileForm.dob"
            type="date" 
            required
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            :disabled="savingProfile"
          >
        </div>

        <!-- Education Qualification -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Education Qualification *</label>
          <select 
            v-model="profileForm.education_qualification"
            required
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            :disabled="savingProfile"
          >
            <option value="">Select qualification</option>
            <option value="HSC">HSC</option>
            <option value="BSC">BSC</option>
            <option value="BA">BA</option>
            <option value="MA">MA</option>
            <option value="MSC">MSC</option>
            <option value="PhD">PhD</option>
            <option value="Other">Other</option>
          </select>
        </div>

        <!-- Institute -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Institute *</label>
          <input 
            v-model="profileForm.institute"
            type="text" 
            required
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="e.g., University of Technology"
            :disabled="savingProfile"
          >
        </div>

        <!-- Experience -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Experience (years)</label>
          <input 
            v-model="profileForm.experience"
            type="number" 
            min="0"
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Enter years of experience"
            :disabled="savingProfile"
          >
        </div>

        <!-- Bio -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Bio</label>
          <textarea 
            v-model="profileForm.bio"
            rows="3"
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Tell us about yourself..."
            :disabled="savingProfile"
          ></textarea>
        </div>

        <!-- Form Actions -->
        <div class="flex justify-end space-x-3 pt-4 border-t border-gray-200">
          <button 
            type="button"
            @click="showEditProfileModal = false"
            class="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            :disabled="savingProfile"
          >
            Cancel
          </button>
          <button 
            type="submit"
            :disabled="savingProfile"
            class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center"
          >
            <svg v-if="savingProfile" class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
              <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
              <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            {{ savingProfile ? 'Saving...' : 'Save Changes' }}
          </button>
        </div>
      </form>
    </div>
  </div>

  <!-- Message Modal -->
  <div v-if="showMessageModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
    <div class="bg-white rounded-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto mx-4">
      <div class="px-6 py-4 border-b border-gray-200">
        <h3 class="text-lg font-semibold text-gray-800">Send Message</h3>
      </div>

      <form @submit.prevent="sendMessageToAdmin" class="p-6 space-y-4">
        <!-- Recipient -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">To</label>
          <select 
            v-model="messageForm.recipient"
            required
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Select recipient</option>
            <option value="admin">School Administrator</option>
            <option value="principal">Principal</option>
            <option value="support">Technical Support</option>
          </select>
        </div>

        <!-- Subject -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Subject *</label>
          <input 
            v-model="messageForm.subject"
            type="text" 
            required
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Enter message subject"
          >
        </div>

        <!-- Message -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Message *</label>
          <textarea 
            v-model="messageForm.message"
            rows="6"
            required
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Type your message here..."
          ></textarea>
        </div>

        <!-- Priority -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Priority</label>
          <select 
            v-model="messageForm.priority"
            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="normal">Normal</option>
            <option value="high">High</option>
            <option value="urgent">Urgent</option>
          </select>
        </div>

        <!-- Form Actions -->
        <div class="flex justify-end space-x-3 pt-4 border-t border-gray-200">
          <button 
            type="button"
            @click="showMessageModal = false"
            class="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button 
            type="submit"
            :disabled="sendingMessage"
            class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            {{ sendingMessage ? 'Sending...' : 'Send Message' }}
          </button>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { Link, router } from '@inertiajs/vue3'
import TeacherSidebar from '../Layout/TeacherSidebar.vue'

// Props from Laravel
const props = defineProps({
  teacher: Object,
  teacherClasses: Array,
  recentResources: Array,
})

// UI State
const userMenuOpen = ref(false)
const isDark = ref(false)
const showUploadModal = ref(false)
const showEditProfileModal = ref(false)
const showMessageModal = ref(false)
const showProfilePictureModal = ref(false)
const uploading = ref(false)
const savingProfile = ref(false)
const sendingMessage = ref(false)
const uploadingPicture = ref(false)

// Profile Picture State
const selectedFile = ref(null)
const profilePicturePreview = ref(null)
const isDragging = ref(false)
const uploadError = ref(null)
const fileInput = ref(null)

// Forms
const newResource = ref({
  type: '',
  title: '',
  description: '',
  content: '',
  assigned_class: '',
  file: null
})

const profileForm = ref({
  name: '',
  email: '',
  username: '',
  dob: '',
  education_qualification: '',
  institute: '',
  experience: '',
  bio: ''
})

const messageForm = ref({
  recipient: '',
  subject: '',
  message: '',
  priority: 'normal'
})

// Computed
const userInitials = computed(() => {
  if (!props.teacher?.name) return 'T'
  return props.teacher.name
    .split(' ')
    .map(word => word[0])
    .join('')
    .toUpperCase()
    .slice(0, 2)
})

const totalStudents = computed(() => {
  return props.teacherClasses.reduce((sum, classItem) => sum + (classItem.studentCount || 0), 0)
})

// Profile Picture Methods
const triggerProfilePictureUpload = () => {
  showProfilePictureModal.value = true
  uploadError.value = null
  selectedFile.value = null
  profilePicturePreview.value = null
}

const triggerProfilePictureUploadFromEdit = () => {
  showEditProfileModal.value = false
  triggerProfilePictureUpload()
}

const triggerFileInput = () => {
  fileInput.value?.click()
}

const handleFileSelect = (event) => {
  const file = event.target.files[0]
  if (file) {
    validateAndSetFile(file)
  }
}

const handleDrop = (event) => {
  event.preventDefault()
  isDragging.value = false
  
  const files = event.dataTransfer.files
  if (files.length > 0) {
    validateAndSetFile(files[0])
  }
}

const handleDragOver = (event) => {
  event.preventDefault()
  isDragging.value = true
}

const handleDragLeave = (event) => {
  event.preventDefault()
  isDragging.value = false
}

const validateAndSetFile = (file) => {
  uploadError.value = null
  
  // Validate file type
  const validTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif']
  if (!validTypes.includes(file.type)) {
    uploadError.value = 'Please select a valid image file (JPEG, PNG, JPG, GIF)'
    return
  }
  
  // Validate file size (2MB)
  if (file.size > 2 * 1024 * 1024) {
    uploadError.value = 'File size must be less than 2MB'
    return
  }
  
  selectedFile.value = file
  
  // Create preview
  const reader = new FileReader()
  reader.onload = (e) => {
    profilePicturePreview.value = e.target.result
  }
  reader.readAsDataURL(file)
}

const uploadProfilePicture = async () => {
  if (!selectedFile.value) return
  
  uploadingPicture.value = true
  uploadError.value = null
  
  try {
    const formData = new FormData()
    formData.append('profile_picture', selectedFile.value)
    
    const response = await fetch(`/api/profile-picture/teacher/${props.teacher.id}/upload`, {
      method: 'POST',
      headers: {
        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
        'Accept': 'application/json', // Explicitly ask for JSON
      },
      body: formData
    })
    
    // Check if response is JSON
    const contentType = response.headers.get('content-type');
    let result;
    
    if (contentType && contentType.includes('application/json')) {
      result = await response.json();
    } else {
      // Handle non-JSON response (likely an error page)
      const text = await response.text();
      console.error('Non-JSON response:', text);
      throw new Error('Server returned an error. Please try again.');
    }
    
    if (result.success) {
      // Update the teacher object with new profile picture URL
      props.teacher.profile_picture_url = result.profile_picture_url
      props.teacher.profile_picture = result.profile_picture_path
      
      showProfilePictureModal.value = false
      selectedFile.value = null
      profilePicturePreview.value = null
      
      // Show success message
      alert('Profile picture updated successfully!')
    } else {
      uploadError.value = result.message || 'Failed to upload profile picture'
    }
  } catch (error) {
    console.error('Error uploading profile picture:', error)
    uploadError.value = error.message || 'An error occurred while uploading the picture'
    
    // If it's a server error, show more details
    if (error.message.includes('Server returned an error')) {
      uploadError.value = 'Server error occurred. Please check if the upload endpoint is working.';
    }
  } finally {
    uploadingPicture.value = false
  }
}

const removeProfilePicture = async () => {
  if (!confirm('Are you sure you want to remove your profile picture?')) {
    return
  }
  
  uploadingPicture.value = true
  
  try {
    const response = await fetch(`/api/profile-picture/teacher/${props.teacher.id}`, {
      method: 'DELETE',
      headers: {
        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
        'Content-Type': 'application/json',
      },
    })
    
    const result = await response.json()
    
    if (result.success) {
      // Remove profile picture from teacher object
      props.teacher.profile_picture_url = null
      props.teacher.profile_picture = null
      
      alert('Profile picture removed successfully!')
    } else {
      alert(result.message || 'Failed to remove profile picture')
    }
  } catch (error) {
    console.error('Error removing profile picture:', error)
    alert('An error occurred while removing the picture')
  } finally {
    uploadingPicture.value = false
  }
}

const cancelProfilePictureUpload = () => {
  showProfilePictureModal.value = false
  selectedFile.value = null
  profilePicturePreview.value = null
  uploadError.value = null
}

// Helper Functions
const getUserInitials = (name) => {
  if (!name) return 'T'
  return name
    .split(' ')
    .map(word => word[0])
    .join('')
    .toUpperCase()
    .slice(0, 2)
}

const formatDate = (dateString) => {
  if (!dateString) return 'N/A'
  return new Date(dateString).toLocaleDateString()
}

const getClassStatusColor = (status) => {
  const colors = {
    'Active': 'bg-green-100 text-green-800',
    'Inactive': 'bg-gray-100 text-gray-800',
    'Upcoming': 'bg-blue-100 text-blue-800'
  }
  return colors[status] || 'bg-gray-100 text-gray-800'
}

const getResourceTypeColor = (type) => {
  const colors = {
    'video': 'bg-red-500',
    'pdf': 'bg-red-600',
    'document': 'bg-blue-500',
    'link': 'bg-green-500'
  }
  return colors[type] || 'bg-gray-500'
}

const formatExperience = (experience) => {
  if (!experience) return '0 years'
  if (typeof experience === 'string') {
    if (experience.includes('years') || experience.includes('year')) {
      return experience
    }
    if (!isNaN(experience)) {
      return `${experience} ${experience === '1' ? 'year' : 'years'}`
    }
  }
  if (typeof experience === 'number') {
    return `${experience} ${experience === 1 ? 'year' : 'years'}`
  }
  return experience || 'Not specified'
}

const getExperienceLevel = (experience) => {
  if (!experience) return null
  let years = 0
  if (typeof experience === 'string') {
    const match = experience.match(/(\d+)/)
    years = match ? parseInt(match[1]) : 0
  } else if (typeof experience === 'number') {
    years = experience
  }
  if (years >= 15) {
    return { level: 'Expert', color: 'bg-purple-100 text-purple-800' }
  } else if (years >= 10) {
    return { level: 'Senior', color: 'bg-blue-100 text-blue-800' }
  } else if (years >= 5) {
    return { level: 'Experienced', color: 'bg-green-100 text-green-800' }
  } else if (years >= 2) {
    return { level: 'Intermediate', color: 'bg-yellow-100 text-yellow-800' }
  } else {
    return { level: 'Beginner', color: 'bg-gray-100 text-gray-800' }
  }
}

// Navigation Methods
const navigateToAllClasses = () => {
  router.visit('/teacher/classes')
}

const navigateToClassSchedule = () => {
  router.visit('/teacher/classes/schedule')
}

const navigateToStudentRoster = () => {
  router.visit('/teacher/classes/students')
}

const navigateToMyResources = () => {
  router.visit('/teacher/resources')
}

const navigateToSharedResources = () => {
  router.visit('/teacher/resources/shared')
}

const navigateToGradeAssignments = () => {
  router.visit('/teacher/assignments')
}

const navigateToStudentProgress = () => {
  router.visit('/teacher/assignments/progress')
}

const navigateToSettings = () => {
  router.visit('/teacher/settings')
}

const viewClass = (classId) => {
  router.visit(`/teacher/class/${classId}`)
}

const createAssignment = () => {
  if (props.teacherClasses.length > 0) {
    router.visit(`/teacher/class/${props.teacherClasses[0].id}/assignments/create`)
  } else {
    router.visit('/teacher/assignments/create')
  }
}

const editProfile = () => {
  profileForm.value = {
    name: props.teacher?.name || '',
    email: props.teacher?.email || '',
    username: props.teacher?.username || '',
    dob: props.teacher?.dob || '',
    education_qualification: props.teacher?.education_qualification || '',
    institute: props.teacher?.institute || '',
    experience: props.teacher?.experience || '',
    bio: props.teacher?.bio || ''
  }
  showEditProfileModal.value = true
}

const sendMessage = () => {
  showMessageModal.value = true
}

const scheduleClass = () => {
  if (props.teacherClasses.length > 0) {
    router.visit(`/teacher/class/${props.teacherClasses[0].id}/schedule`)
  } else {
    alert('No classes available to schedule.')
  }
}

const goBackToAdmin = () => {
  router.visit('/admin/users/other-users')
}

const logout = async () => {
  try {
    router.post('/logout')
  } catch (err) {
    console.error('Logout error:', err)
  }
}

// Modal Methods
const uploadResource = async () => {
  if (!newResource.value.type || !newResource.value.title) {
    alert('Please fill in all required fields')
    return
  }
  uploading.value = true
  // Simulate upload
  setTimeout(() => {
    uploading.value = false
    showUploadModal.value = false
    alert('Resource uploaded successfully!')
    resetResourceForm()
  }, 1500)
}

const handleFileUpload = (event) => {
  const file = event.target.files[0]
  if (file) {
    newResource.value.file = file
    newResource.value.content = file.name
  }
}

const resetResourceForm = () => {
  newResource.value = {
    type: '',
    title: '',
    description: '',
    content: '',
    assigned_class: '',
    file: null
  }
}

const saveProfile = async () => {
  savingProfile.value = true
  
  try {
    const response = await fetch(`/api/teacher/${props.teacher.id}/profile`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
        'Accept': 'application/json',
      },
      body: JSON.stringify(profileForm.value)
    })

    const result = await response.json()

    if (result.success) {
      // Update the teacher object with new data
      Object.assign(props.teacher, profileForm.value)
      showEditProfileModal.value = false
      alert('Profile updated successfully!')
    } else {
      alert(result.message || 'Failed to update profile')
    }
  } catch (error) {
    console.error('Error updating profile:', error)
    alert('An error occurred while updating the profile')
  } finally {
    savingProfile.value = false
  }
}

const sendMessageToAdmin = async () => {
  sendingMessage.value = true
  // Simulate send
  setTimeout(() => {
    sendingMessage.value = false
    showMessageModal.value = false
    resetMessageForm()
    alert('Message sent successfully!')
  }, 1500)
}

const resetMessageForm = () => {
  messageForm.value = {
    recipient: '',
    subject: '',
    message: '',
    priority: 'normal'
  }
}

// UI Methods
const toggleTheme = () => {
  isDark.value = !isDark.value
  document.documentElement.classList.toggle('dark', isDark.value)
}

const toggleUserMenu = () => {
  userMenuOpen.value = !userMenuOpen.value
}

const handleClickOutside = (event) => {
  if (!event.target.closest('.relative')) {
    userMenuOpen.value = false
  }
}

// Lifecycle
onMounted(() => {
  document.addEventListener('click', handleClickOutside)
  
  // Ensure teacher object has profile_picture_url
  if (props.teacher?.profile_picture && !props.teacher.profile_picture_url) {
    props.teacher.profile_picture_url = `/storage/${props.teacher.profile_picture}`
  }
})
</script>

<style scoped>
/* Use deep selector to override */
:deep(*) {
    font-family: "Nunito Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol" !important;
    font-weight: 400;
}

.custom-heading {
    font-family: "Nunito Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol" !important;
}

.rotate-180 {
  transform: rotate(180deg);
}

.submenu-link {
  display: block;
  padding: 0.5rem 0.75rem;
  color: #4b5563;
  border-radius: 0.5rem;
  transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out;
}

.submenu-link:hover {
  color: #4f46e5;
  background-color: #f9fafb;
}

/* Profile picture hover effects */
.group:hover .group-hover\:opacity-100 {
  opacity: 1;
}

:deep(*) {
    font-family: "Nunito Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol" !important;
    font-weight: 400;
}

.custom-heading {
    font-family: "Nunito Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol" !important;
}
</style>