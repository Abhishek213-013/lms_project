<template>
  <FrontendLayout>
    <main class="main-area fix">
      <!-- instructor-details-area -->
      <section class="instructor__details-area section-pt-120 section-pb-90">
        <div class="container">
          <div class="row">
            <!-- Sidebar - Profile, Experience, Education -->
            <div class="col-xl-4 col-lg-5">
              <div class="instructor__sidebar">
                <!-- Teacher Profile Card -->
                <div class="sidebar-card profile-card">
                  <div class="profile-header">
                    <div class="profile-avatar">
                      <img 
                        :src="profilePictureUrl" 
                        :alt="instructor.name" 
                        @error="handleProfilePictureError"
                        class="profile-picture"
                      >
                      <!-- Upload overlay for teacher's own profile -->
                      <!-- <div 
                        v-if="canEditProfile" 
                        class="profile-upload-overlay"
                        @click="triggerProfilePictureUpload"
                      >
                        <i class="fas fa-camera"></i>
                        <span>{{ t('Change Photo') }}</span>
                      </div> -->
                    </div>
                    <div class="profile-info">
                      <h2 class="title">{{ instructor.name }}</h2>
                      <span class="designation">{{ getInstructorTitle(instructor) }}</span>
                      <div class="rating">
                        <i class="fas fa-star"></i>
                        <span>{{ instructor.rating }} ({{ instructor.reviews }} {{ t('reviews') }})</span>
                      </div>
                    </div>
                  </div>
                  
                  <div class="profile-stats">
                    <div class="stat-item">
                      <div class="stat-icon">
                        <i class="fas fa-book-open"></i>
                      </div>
                      <div class="stat-info">
                        <span class="stat-number">{{ stats.totalClasses }}</span>
                        <span class="stat-label">{{ t('Total Classes') }}</span>
                      </div>
                    </div>
                    <div class="stat-item">
                      <div class="stat-icon">
                        <i class="fas fa-users"></i>
                      </div>
                      <div class="stat-info">
                        <span class="stat-number">{{ stats.totalStudents }}+</span>
                        <span class="stat-label">{{ t('Students Taught') }}</span>
                      </div>
                    </div>
                    <div class="stat-item">
                      <div class="stat-icon">
                        <i class="fas fa-video"></i>
                      </div>
                      <div class="stat-info">
                        <span class="stat-number">{{ stats.totalVideos }}</span>
                        <span class="stat-label">{{ t('Demo Videos') }}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div class="profile-details">
                    <div class="detail-item">
                      <label><i class="fas fa-user-graduate"></i> {{ t('Expertise') }}</label>
                      <span>{{ instructor.expertise }}</span>
                    </div>
                    <div class="detail-item">
                      <label><i class="fas fa-language"></i> {{ t('Languages') }}</label>
                      <span>{{ instructor.languages }}</span>
                    </div>
                    <div class="detail-item">
                      <label><i class="fas fa-clock"></i> {{ t('Response Time') }}</label>
                      <span>{{ instructor.response_time }}</span>
                    </div>
                    <div class="detail-item">
                      <label><i class="fas fa-envelope"></i> {{ t('Email') }}</label>
                      <span><a :href="`mailto:${instructor.email}`">{{ instructor.email }}</a></span>
                    </div>
                    <div class="detail-item">
                      <label><i class="fas fa-phone"></i> {{ t('Experience') }}</label>
                      <span>{{ stats.experience_years }}+ {{ t('years') }}</span>
                    </div>
                  </div>
                  
                  <div class="profile-bio">
                    <p>{{ instructor.bio }}</p>
                  </div>
                  
                  <div class="profile-social">
                    <h5>{{ t('Follow Instructor') }}</h5>
                    <ul class="list-wrap">
                      <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                      <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                      <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                      <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                      <li><a href="#"><i class="fab fa-youtube"></i></a></li>
                    </ul>
                  </div>
                </div>

                <!-- Experience Card -->
                <div class="sidebar-card experience-card">
                  <h4 class="title">{{ t('Teaching Experience') }}</h4>
                  <div class="experience-timeline">
                    <div class="experience-item">
                      <div class="exp-period">{{ stats.experience_years }}+ {{ t('Years') }}</div>
                      <div class="exp-dot"></div>
                      <div class="exp-content">
                        <h6>{{ getInstructorTitle(instructor) }}</h6>
                        <p class="exp-company">{{ instructor.institute || t('Educational Institution') }}</p>
                        <p class="exp-description">{{ t('Teaching') }} {{ instructor.expertise || t('various subjects') }}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Education Card -->
                <div class="sidebar-card education-card">
                  <h4 class="title">{{ t('Education & Certification') }}</h4>
                  <div class="education-list">
                    <div class="education-item">
                      <div class="edu-icon">
                        <i class="fas fa-graduation-cap"></i>
                      </div>
                      <div class="edu-content">
                        <h6>{{ instructor.education_qualification || t('Teaching Certification') }}</h6>
                        <p class="edu-institution">{{ instructor.institute || t('Educational Institution') }}</p>
                        <p class="edu-year">{{ new Date().getFullYear() - stats.experience_years }}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- Main Content - Demo Class Videos, Classes -->
            <div class="col-xl-8 col-lg-7">
              <div class="instructor__details-wrap">
                <!-- Demo Class Videos Section -->
                <div class="demo-videos-section">
                  <div class="section-header">
                    <h3 class="main-title">{{ t('Class Videos') }}</h3>
                    <p>{{ t('Watch classes to experience teaching style') }}</p>
                  </div>

                  <!-- Video Categories Navigation -->
                  <div class="video-categories-nav" v-if="videos.length > 0">
                    <button 
                      @click="setActiveCategory('all')"
                      :class="['category-btn', { 'active': activeCategory === 'all' }]"
                    >
                      {{ t('All Videos') }}
                    </button>
                    <button 
                      v-for="classItem in uniqueClasses" 
                      :key="classItem.id"
                      @click="setActiveCategory(classItem.id)"
                      :class="['category-btn', { 'active': activeCategory === classItem.id }]"
                    >
                      {{ classItem.name }}
                    </button>
                  </div>

                  <!-- Videos Content -->
                  <div class="videos-content" v-if="filteredVideos.length > 0">
                    
                    <!-- Intro Video Section -->
                    <div class="intro-video-section" v-if="introVideo">
                      <h4 class="section-subtitle">{{ t('Intro') }}</h4>
                      <div class="intro-video-card" @click="playVideo(introVideo)">
                        <div class="intro-video-thumbnail">
                          <img :src="getVideoThumbnail(introVideo)" :alt="introVideo.title" @error="handleVideoThumbnailError">
                          <div class="video-overlay">
                            <div class="play-button">
                              <i class="fas fa-play"></i>
                            </div>
                            <div class="video-duration">{{ introVideo.duration || '15:30' }}</div>
                            <div class="video-badge">{{ t('Intro') }}</div>
                          </div>
                        </div>
                        <div class="intro-video-content">
                          <h5 class="video-title">{{ getCleanTitle(introVideo.title) }}</h5>
                          <div class="video-stats-simple">
                            <span><i class="far fa-clock"></i> {{ introVideo.duration || '15:30' }}</span>
                            <span><i class="far fa-calendar"></i> {{ formatDate(introVideo.created_at) }}</span>
                            <span class="video-class">{{ getClassName(introVideo.class_id) }}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- Class-wise Video Sections -->
                    <div class="class-videos-sections">
                      <div 
                        v-for="classItem in classesWithVideos" 
                        :key="classItem.id"
                        class="class-videos-section"
                        v-show="activeCategory === 'all' || activeCategory === classItem.id"
                      >
                        <h4 class="section-subtitle">{{ classItem.name }}</h4>
                        <div class="class-videos-horizontal">
                          <div 
                            v-for="video in getVideosByClass(classItem.id)" 
                            :key="video.id"
                            class="video-card-horizontal"
                            @click="playVideo(video)"
                          >
                            <div class="video-thumbnail-horizontal">
                              <img :src="getVideoThumbnail(video)" :alt="video.title" @error="handleVideoThumbnailError">
                              <div class="video-overlay-horizontal">
                                <div class="play-button-horizontal">
                                  <i class="fas fa-play"></i>
                                </div>
                                <div class="video-duration-horizontal">{{ video.duration || '15:30' }}</div>
                                <div class="video-badge-horizontal">{{ t('Demo') }}</div>
                              </div>
                            </div>
                            <div class="video-content-horizontal">
                              <h5 class="video-title-horizontal">{{ getCleanTitle(video.title) }}</h5>
                              <div class="video-meta-simple">
                                <span><i class="far fa-clock"></i> {{ video.duration || '15:30' }}</span>
                                <span><i class="far fa-calendar"></i> {{ formatDate(video.created_at) }}</span>
                                <span class="video-class-simple">{{ getClassName(video.class_id) }}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- No Videos Message -->
                  <div v-if="videos.length === 0" class="text-center py-8">
                    <i class="fas fa-video-slash fa-3x text-gray-400 mb-4"></i>
                    <h4 class="text-gray-600">{{ t('No Videos Available') }}</h4>
                    <p class="text-gray-500">{{ t('This instructor hasn\'t uploaded any demo videos yet.') }}</p>
                  </div>

                  <!-- No Videos in Category Message -->
                  <div v-if="filteredVideos.length === 0 && videos.length > 0" class="text-center py-8">
                    <i class="fas fa-filter fa-3x text-gray-400 mb-4"></i>
                    <h4 class="text-gray-600">{{ t('No videos in this class') }}</h4>
                    <p class="text-gray-500">{{ t('Try selecting a different class to see more videos.') }}</p>
                  </div>

                  <!-- Load More Button -->
                  <div v-if="showLoadMore" class="text-center mt-5">
                    <button class="btn btn-primary" @click="loadMoreVideos">
                      {{ t('Load More Videos') }}
                    </button>
                  </div>
                </div>

                <!-- Classes Taught Section -->
                <div class="classes-section" v-if="classes.length > 0">
                  <div class="section-header">
                    <h3 class="main-title">{{ t('Classes Taught') }}</h3>
                    <p>{{ t('Subjects and classes currently being taught') }}</p>
                  </div>
                  <div class="classes-grid">
                    <div 
                      v-for="classItem in classes" 
                      :key="classItem.id"
                      class="class-card"
                    >
                      <div class="class-header">
                        <h5 class="class-name">{{ classItem.name }}</h5>
                        <span class="class-status active">
                          {{ t('Active') }}
                        </span>
                      </div>
                      <div class="class-details">
                        <div class="class-subject">
                          <i class="fas fa-book"></i>
                          <span>{{ classItem.subject }}</span>
                        </div>
                        <div class="class-grade" v-if="classItem.grade">
                          <i class="fas fa-graduation-cap"></i>
                          <span>{{ t('Grade') }} {{ classItem.grade }}</span>
                        </div>
                        <div class="class-students">
                          <i class="fas fa-users"></i>
                          <span>{{ classItem.student_count }} {{ t('students') }}</span>
                        </div>
                      </div>
                      <div class="class-description">
                        <p>{{ classItem.description || t('Comprehensive course covering essential topics') }}</p>
                      </div>
                      <div class="class-actions">
                        <Link :href="`/course/${classItem.id}`" class="btn btn-sm btn-outline">
                          {{ t('View Course') }}
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- No Classes Message -->
                <div v-if="classes.length === 0 && videos.length === 0" class="text-center py-8">
                  <i class="fas fa-info-circle fa-3x text-gray-400 mb-4"></i>
                  <h4 class="text-gray-600">{{ t('Content Coming Soon') }}</h4>
                  <p class="text-gray-500">{{ t('This instructor hasn\'t uploaded any content yet.') }}</p>
                </div>

                <!-- Teaching Philosophy - Always show the section -->
                <div class="instructor__details-biography">
                  <h4 class="title">{{ t('Teaching Philosophy') }}</h4>
                  <p>{{ instructor.bio || instructor.teaching_philosophy || t('This instructor is passionate about education and dedicated to student success.') }}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Profile Picture Upload Modal -->
      <div v-if="showProfilePictureModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
        <div class="bg-white rounded-lg w-full max-w-md mx-4">
          <div class="px-6 py-4 border-b border-gray-200">
            <h3 class="text-lg font-semibold text-gray-800">{{ t('Upload Profile Picture') }}</h3>
          </div>

          <div class="p-6">
            <!-- Image Preview -->
            <div v-if="profilePicturePreview" class="mb-4 flex justify-center">
              <div class="w-32 h-32 rounded-full overflow-hidden border-4 border-gray-200">
                <img :src="profilePicturePreview" alt="Preview" class="w-full h-full object-cover">
              </div>
            </div>

            <!-- Upload Area -->
            <div 
              @drop="handleDrop"
              @dragover="handleDragOver"
              @dragleave="handleDragLeave"
              :class="`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
                isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400'
              }`"
              @click="triggerFileInput"
            >
              <input 
                type="file" 
                ref="fileInput"
                @change="handleFileSelect"
                accept="image/jpeg,image/png,image/jpg,image/gif"
                class="hidden"
              >
              
              <svg class="w-12 h-12 text-gray-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
              </svg>
              
              <p class="text-gray-600 mb-2">
                <span class="text-blue-600 font-medium">{{ t('Click to upload') }}</span> {{ t('or drag and drop') }}
              </p>
              <p class="text-xs text-gray-500">
                PNG, JPG, GIF {{ t('up to 2MB') }}
              </p>
            </div>

            <!-- Error Message -->
            <div v-if="uploadError" class="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
              <p class="text-sm text-red-600">{{ uploadError }}</p>
            </div>

            <!-- Form Actions -->
            <div class="flex justify-end space-x-3 pt-4 border-t border-gray-200 mt-4">
              <button 
                type="button"
                @click="cancelProfilePictureUpload"
                class="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                {{ t('Cancel') }}
              </button>
              <button 
                type="button"
                @click="uploadProfilePicture"
                :disabled="!selectedFile || uploadingPicture"
                class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center"
              >
                <svg v-if="uploadingPicture" class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                  <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                  <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                {{ uploadingPicture ? t('Uploading...') : t('Upload Picture') }}
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Video Player Modal -->
      <div 
        v-if="showVideoPlayer && currentVideo" 
        class="fixed inset-0 bg-black bg-opacity-95 flex items-center justify-center p-4 z-[9999] video-player-modal"
        @click.self="closeVideoPlayer"
      >
        <div class="bg-white rounded-xl w-full max-w-6xl mx-4 relative z-[10000] flex flex-col h-[90vh]">
          <!-- Modal Header - 20% height -->
          <div class="px-6 py-4 border-b border-gray-200 flex justify-between items-center bg-white rounded-t-xl flex-shrink-0 header-section">
            <div class="flex-1 min-w-0">
              <h3 class="text-xl font-bold text-gray-800 truncate pr-4">{{ currentVideo.title }}</h3>
              <div class="flex flex-wrap gap-3 mt-2 text-sm text-gray-600">
                <span class="flex items-center">
                  <i class="far fa-clock mr-2"></i> {{ currentVideo.duration || 'N/A' }}
                </span>
                <span class="flex items-center">
                  <i class="far fa-calendar mr-2"></i> {{ formatDate(currentVideo.created_at) }}
                </span>
                <span class="video-class bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-xs font-medium">
                  {{ getClassName(currentVideo.class_id) }}
                </span>
              </div>
            </div>
            <button 
              @click="closeVideoPlayer" 
              class="text-gray-500 hover:text-gray-700 transition-colors flex-shrink-0 ml-4"
              aria-label="Close video player"
            >
              <i class="fas fa-times text-2xl"></i>
            </button>
          </div>
          
          <!-- Video Player Section - 70% height -->
          <div class="flex-1 min-h-0 video-player-section bg-black p-0">
            <div class="w-full h-full flex items-center justify-center relative">
              <!-- Loading State -->
              <div v-if="isLoading" class="absolute inset-0 flex items-center justify-center bg-black z-10">
                <div class="text-white text-center">
                  <div class="animate-spin rounded-full h-16 w-16 border-b-2 border-white mx-auto mb-4"></div>
                  <p class="text-lg">{{ t('Loading video...') }}</p>
                </div>
              </div>
              
              <!-- YouTube Embed -->
              <div v-else-if="currentVideo.isEmbed" class="w-full h-full youtube-isolation-fix">
                <iframe 
                  :src="currentVideo.ultraCleanUrl" 
                  frameborder="0" 
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                  allowfullscreen
                  class="w-full h-full"
                  @load="isLoading = false"
                ></iframe>
              </div>
              
              <!-- Direct Video -->
              <div v-else-if="currentVideo.isDirectStream || currentVideo.isDirectVideo" class="w-full h-full">
                <video 
                  ref="videoPlayer"
                  :src="currentVideo.directVideoUrl" 
                  controls
                  controlsList="nodownload"
                  class="w-full h-full"
                  @play="isPlaying = true"
                  @pause="isPlaying = false"
                  @ended="isPlaying = false"
                  @loadeddata="isLoading = false"
                  @error="handleVideoError"
                  autoplay
                >
                  {{ t('Your browser does not support the video tag.') }}
                </video>
              </div>
              
              <!-- Error State -->
              <div v-else class="flex items-center justify-center h-full text-white">
                <div class="text-center">
                  <i class="fas fa-exclamation-triangle text-5xl mb-4 text-yellow-400"></i>
                  <p class="text-xl mb-2">{{ t('Unable to load video') }}</p>
                  <p class="text-gray-400">{{ t('Please try again later.') }}</p>
                </div>
              </div>
              
              <!-- Protective overlay to ensure video stays contained -->
              <div class="absolute inset-0 border-2 border-transparent pointer-events-none"></div>
            </div>
          </div>
          
          <!-- Modal Footer - 10% height -->
          <div class="px-6 py-3 border-t border-gray-200 bg-white rounded-b-xl flex-shrink-0 footer-section">
            <div class="flex justify-between items-center">
              <div class="flex-1 min-w-0">
                <p v-if="currentVideo.description" class="text-gray-700 text-sm truncate" :title="currentVideo.description">
                  {{ currentVideo.description }}
                </p>
                <p v-else class="text-gray-500 text-sm italic">
                  {{ t('No description available') }}
                </p>
              </div>
              <button 
                @click="closeVideoPlayer" 
                class="px-6 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors font-medium flex-shrink-0 ml-4"
              >
                <i class="fas fa-times mr-2"></i>
                {{ t('Close') }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </main>
  </FrontendLayout>
</template>

<script setup>
import { Link } from '@inertiajs/vue3';
import { ref, computed, onMounted, onUnmounted, nextTick } from 'vue';
import FrontendLayout from '../Layout/FrontendLayout.vue';
import { useTranslation } from '@/composables/useTranslation';

// Use the global translation composable
const { currentLanguage, t, switchLanguage } = useTranslation();

// Component props
const props = defineProps({
  instructor: {
    type: Object,
    required: true
  },
  classes: {
    type: Array,
    default: () => []
  },
  videos: {
    type: Array,
    default: () => []
  },
  stats: {
    type: Object,
    default: () => ({})
  },
  auth: {
    type: Object,
    default: () => ({})
  }
});

// Reactive data for profile picture
const showProfilePictureModal = ref(false);
const selectedFile = ref(null);
const profilePicturePreview = ref(null);
const isDragging = ref(false);
const uploadError = ref(null);
const uploadingPicture = ref(false);
const fileInput = ref(null);

// Existing reactive data
const selectedVideo = ref(null);
const currentVideo = ref(null);
const showVideoPlayer = ref(false);
const videoPlayer = ref(null);
const activeCategory = ref('all');
const videosPerPage = ref(6);
const currentPage = ref(1);
const currentTheme = ref('light');
const isPlaying = ref(false);
const isLoading = ref(false);
const iconRenderKey = ref(0);

// Computed properties
const canEditProfile = computed(() => {
  // Check if the authenticated user is viewing their own profile
  return props.auth.user && props.auth.user.id === props.instructor.id;
});

const profilePictureUrl = computed(() => {
  console.log('🔄 [profilePictureUrl] Computing profile picture URL');
  console.log('📊 Instructor profile_picture field:', props.instructor?.profile_picture);
  
  // Use only profile_picture from database
  if (props.instructor?.profile_picture) {
    console.log('✅ Using profile_picture from database:', props.instructor.profile_picture);
    
    // If it's already a full URL, use it directly
    if (props.instructor.profile_picture.startsWith('http')) {
      console.log('🌐 Already a full URL');
      return props.instructor.profile_picture;
    }
    
    // Handle storage path - ensure it starts with /storage/
    let picturePath = props.instructor.profile_picture;
    
    // Remove any leading slashes or storage/ prefixes to avoid double slashes
    picturePath = picturePath.replace(/^\/+/, '').replace(/^storage\//, '');
    
    // Construct the proper URL
    const finalUrl = `/storage/${picturePath}`;
    
    console.log('🖼️ Final profile picture URL:', finalUrl);
    console.log('🔍 Path transformation:', {
      original: props.instructor.profile_picture,
      cleaned: picturePath,
      final: finalUrl
    });
    
    return finalUrl;
  }
  
  // No profile picture found
  console.log('❌ No profile picture found, using default');
  console.log('🔍 Available instructor fields:', Object.keys(props.instructor || {}));
  return '/assets/img/instructor/instructor01.png';
});

// Profile Picture Methods
const triggerProfilePictureUpload = () => {
  if (!canEditProfile.value) return;
  
  showProfilePictureModal.value = true;
  uploadError.value = null;
  selectedFile.value = null;
  profilePicturePreview.value = null;
};

const triggerFileInput = () => {
  fileInput.value?.click();
};

const handleFileSelect = (event) => {
  const file = event.target.files[0];
  if (file) {
    validateAndSetFile(file);
  }
};

const handleDrop = (event) => {
  event.preventDefault();
  isDragging.value = false;
  
  const files = event.dataTransfer.files;
  if (files.length > 0) {
    validateAndSetFile(files[0]);
  }
};

const handleDragOver = (event) => {
  event.preventDefault();
  isDragging.value = true;
};

const handleDragLeave = (event) => {
  event.preventDefault();
  isDragging.value = false;
};

const validateAndSetFile = (file) => {
  uploadError.value = null;
  
  // Validate file type
  const validTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
  if (!validTypes.includes(file.type)) {
    uploadError.value = t('Please select a valid image file (JPEG, PNG, JPG, GIF)');
    return;
  }
  
  // Validate file size (2MB)
  if (file.size > 2 * 1024 * 1024) {
    uploadError.value = t('File size must be less than 2MB');
    return;
  }
  
  selectedFile.value = file;
  
  // Create preview
  const reader = new FileReader();
  reader.onload = (e) => {
    profilePicturePreview.value = e.target.result;
  };
  reader.readAsDataURL(file);
};

const uploadProfilePicture = async () => {
  if (!selectedFile.value || !canEditProfile.value) return;
  
  uploadingPicture.value = true;
  uploadError.value = null;
  
  try {
    const formData = new FormData();
    formData.append('profile_picture', selectedFile.value);
    
    console.log('📤 [uploadProfilePicture] Uploading for instructor:', props.instructor.id);
    
    const response = await fetch(`/api/profile-picture/teacher/${props.instructor.id}/upload`, {
      method: 'POST',
      headers: {
        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
      },
      body: formData
    });
    
    // Handle both JSON and non-JSON responses
    const text = await response.text();
    let result;
    
    try {
      result = JSON.parse(text);
    } catch (parseError) {
      console.error('❌ Failed to parse JSON:', text);
      throw new Error(t('Server returned an invalid response'));
    }
    
    if (result.success) {
      console.log('✅ [uploadProfilePicture] Upload successful:', result);
      
      // Update the instructor object with new profile picture data
      props.instructor.profile_picture = result.profile_picture_path;
      
      showProfilePictureModal.value = false;
      selectedFile.value = null;
      profilePicturePreview.value = null;
      
      // Show success message
      alert(t('Profile picture updated successfully!'));
      
      // Force refresh the page to get updated data from server
      setTimeout(() => {
        window.location.reload();
      }, 1000);
      
    } else {
      uploadError.value = result.message || t('Failed to upload profile picture');
      console.error('❌ [uploadProfilePicture] Upload failed:', result);
    }
  } catch (error) {
    console.error('❌ [uploadProfilePicture] Error:', error);
    uploadError.value = error.message || t('An error occurred while uploading the picture');
  } finally {
    uploadingPicture.value = false;
  }
};

const cancelProfilePictureUpload = () => {
  showProfilePictureModal.value = false;
  selectedFile.value = null;
  profilePicturePreview.value = null;
  uploadError.value = null;
};

const handleProfilePictureError = (event) => {
  console.log('❌ Profile picture failed to load, using fallback');
  event.target.src = '/assets/img/instructor/instructor01.png';
};

// ... rest of the methods remain the same ...

// Video related computed properties
const uniqueClasses = computed(() => {
  return props.classes.filter((classItem, index, self) => 
    index === self.findIndex(c => c.id === classItem.id)
  );
});

const introVideo = computed(() => {
  if (props.videos.length === 0) return null;
  
  const firstClassWithVideos = classesWithVideos.value[0];
  if (!firstClassWithVideos) return props.videos[0];
  
  const firstClassVideos = getVideosByClass(firstClassWithVideos.id);
  return firstClassVideos[0] || props.videos[0];
});

const classesWithVideos = computed(() => {
  const classMap = new Map();
  
  props.classes.forEach(classItem => {
    const classVideos = props.videos.filter(video => 
      String(video.class_id) === String(classItem.id)
    );
    if (classVideos.length > 0) {
      classMap.set(classItem.id, classItem);
    }
  });
  
  return Array.from(classMap.values());
});

const handleVideoError = (event) => {
  console.error('❌ Video playback error:', event);
  isLoading.value = false;
  
  // Fallback to YouTube embed if direct video fails
  if (currentVideo.value && currentVideo.value.videoId && !currentVideo.value.isEmbed) {
    console.log('🔄 Falling back to YouTube embed due to video error');
    currentVideo.value = {
      ...currentVideo.value,
      ultraCleanUrl: generateUltraCleanEmbedUrl(currentVideo.value.videoId),
      isEmbed: true,
      isDirectStream: false,
      isDirectVideo: false
    };
  }
};


const filteredVideos = computed(() => {
  let filtered = [];
  
  if (activeCategory.value === 'all') {
    filtered = props.videos;
  } else {
    filtered = props.videos.filter(video => 
      String(video.class_id) === String(activeCategory.value)
    );
  }
  
  return filtered.slice(0, videosPerPage.value * currentPage.value);
});

const showLoadMore = computed(() => {
  let totalVideos = 0;
  
  if (activeCategory.value === 'all') {
    totalVideos = props.videos.length;
  } else {
    totalVideos = props.videos.filter(v => 
      String(v.class_id) === String(activeCategory.value)
    ).length;
  }
  
  return filteredVideos.value.length < totalVideos;
});

// Utility methods
const getCleanTitle = (title) => {
  if (!title) return t('Untitled Video');
  
  let cleanTitle = title.replace(/https?:\/\/[^\s]+/g, '').trim();
  cleanTitle = cleanTitle.replace(/youtu\.be\/[^\s]+/g, '');
  cleanTitle = cleanTitle.replace(/youtube\.com\/watch\?v=[^\s]+/g, '');
  cleanTitle = cleanTitle.replace(/\?si=[^\s]+/g, '');
  cleanTitle = cleanTitle.replace(/\s+/g, ' ').trim();
  
  if (!cleanTitle) return t('Demo Video');
  
  return cleanTitle;
};

const getInstructorTitle = (instructor) => {
  if (instructor.education_qualification) {
    const qual = instructor.education_qualification;
    const titles = {
      'en': {
        'PhD': 'PhD Specialist',
        'MA': 'Master Educator',
        'MSC': 'Science Expert',
        'BA': 'Bachelor Educator',
        'BSC': 'Science Teacher',
        'HSC': 'Certified Teacher',
        'Other': 'Professional Instructor'
      },
      'bn': {
        'PhD': 'পিএইচডি বিশেষজ্ঞ',
        'MA': 'মাস্টার শিক্ষক',
        'MSC': 'বিজ্ঞান বিশেষজ্ঞ',
        'BA': 'ব্যাচেলর শিক্ষক',
        'BSC': 'বিজ্ঞান শিক্ষক',
        'HSC': 'সার্টিফাইড শিক্ষক',
        'Other': 'পেশাদার ইন্সট্রাক্টর'
      }
    };
    return titles[currentLanguage.value]?.[qual] || `${qual} ${t('Certified')}`;
  }
  return t('Professional Instructor');
};

const getClassName = (classId) => {
  if (!classId) return t('General Education');
  const classItem = props.classes.find(c => String(c.id) === String(classId));
  return classItem ? classItem.name : t('General Education');
};

const getVideoThumbnail = (video) => {
  if (video.thumbnail && video.thumbnail !== '/images/default-video-thumbnail.jpg') {
    return video.thumbnail;
  }
  
  const videoContent = getVideoContent(video);
  if (videoContent && isYouTubeUrl(videoContent)) {
    const videoId = getYouTubeVideoId(videoContent);
    if (videoId) {
      return `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
    }
  }
  
  return '/assets/img/courses/video_thumb01.jpg';
};

const getVideoContent = (video) => {
  if (!video) return null;
  
  const possibleFields = [
    'content',
    'file_path',
    'url',
    'video_url',
    'link',
    'source',
    'video_content',
    'youtube_url',
    'resource_url',
    'videoUrl'
  ];
  
  for (const field of possibleFields) {
    if (video[field] && typeof video[field] === 'string') {
      const value = video[field].trim();
      if (value.startsWith('http')) {
        return value;
      }
      
      if ((value.includes('youtube.com') || value.includes('youtu.be')) && !value.startsWith('http')) {
        return 'https://' + value.replace(/^\/\//, '');
      }
    }
  }
  
  return null;
};

const isYouTubeUrl = (url) => {
  if (!url || typeof url !== 'string') return false;
  
  const cleanUrl = url.trim();
  const youtubePatterns = [
    /youtube\.com\/watch\?v=([a-zA-Z0-9_-]+)/,
    /youtu\.be\/([a-zA-Z0-9_-]+)/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]+)/,
    /youtube\.com\/v\/([a-zA-Z0-9_-]+)/,
    /youtube\.com\/.*[?&]v=([a-zA-Z0-9_-]+)/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]+)/,
    /youtube\.com\/live\/([a-zA-Z0-9_-]+)/
  ];
  
  return youtubePatterns.some(pattern => pattern.test(cleanUrl));
};

const getYouTubeVideoId = (url) => {
  if (!url || typeof url !== 'string') return null;
  
  const cleanUrl = url.trim();
  const patterns = [
    /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
    /youtu\.be\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/v\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/.*[?&]v=([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/live\/([a-zA-Z0-9_-]{11})/
  ];
  
  for (const pattern of patterns) {
    const match = cleanUrl.match(pattern);
    if (match && match[1]) {
      return match[1];
    }
  }
  
  return null;
};

const getVideosByClass = (classId) => {
  const allVideos = props.videos.filter(video => 
    String(video.class_id) === String(classId)
  );
  
  const firstClass = classesWithVideos.value[0];
  if (firstClass && String(classId) === String(firstClass.id) && introVideo.value) {
    return allVideos.filter(video => video.id !== introVideo.value.id);
  }
  
  return allVideos;
};

const formatDate = (dateString) => {
  if (!dateString) return 'N/A';
  try {
    const options = {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    };
    
    if (currentLanguage.value === 'bn') {
      return new Date(dateString).toLocaleDateString('bn-BD', options);
    }
    
    return new Date(dateString).toLocaleDateString('en-US', options);
  } catch (error) {
    return t('Invalid Date');
  }
};

const setActiveCategory = (categoryId) => {
  activeCategory.value = categoryId;
  currentPage.value = 1;
};

const loadMoreVideos = () => {
  currentPage.value++;
};

const handleVideoThumbnailError = (event) => {
  event.target.src = '/assets/img/courses/video_thumb01.jpg';
};

// Video player methods
const playVideo = async (video) => {
  console.log('🎬 [playVideo] Attempting to play video:', video.title);
  isLoading.value = true;
  showVideoPlayer.value = true;
  
  try {
    const cleanVideo = {
      ...video,
      title: getCleanTitle(video.title),
      description: video.description || ''
    };
    
    const videoContent = getVideoContent(video);
    
    if (!videoContent) {
      throw new Error('No video content found');
    }
    
    if (isYouTubeUrl(videoContent)) {
      const videoId = getYouTubeVideoId(videoContent);
      
      if (videoId) {
        console.log('✅ Playing YouTube video with ID:', videoId);
        
        // Try direct stream first
        const directVideoUrl = await getDirectVideoStream(videoId);
        
        if (directVideoUrl) {
          console.log('🎯 Using direct video stream');
          currentVideo.value = {
            ...cleanVideo,
            directVideoUrl: directVideoUrl,
            videoId: videoId,
            thumbnail: getVideoThumbnail(video),
            isDirectStream: true,
            isEmbed: false,
            isDirectVideo: false
          };
        } else {
          console.log('🔄 Using ultra-clean embed as fallback');
          currentVideo.value = {
            ...cleanVideo,
            ultraCleanUrl: generateUltraCleanEmbedUrl(videoId),
            videoId: videoId,
            originalUrl: videoContent,
            isEmbed: true,
            isDirectStream: false,
            isDirectVideo: false
          };
        }
      } else {
        throw new Error('Could not extract YouTube video ID');
      }
    } else {
      console.log('🎯 Using direct video file');
      currentVideo.value = {
        ...cleanVideo,
        directVideoUrl: videoContent,
        isDirectVideo: true,
        isEmbed: false,
        isDirectStream: false
      };
    }
    
  } catch (error) {
    console.error('❌ Error preparing video:', error);
    alert(`Error loading video: ${error.message}`);
    closeVideoPlayer();
  } finally {
    isLoading.value = false;
  }
};

const closeVideoPlayer = () => {
  console.log('🔴 Closing video player');
  
  // Pause and reset video if playing
  if (videoPlayer.value && typeof videoPlayer.value.pause === 'function') {
    videoPlayer.value.pause();
    videoPlayer.value.currentTime = 0;
  }
  
  // Reset states
  showVideoPlayer.value = false;
  currentVideo.value = null;
  isPlaying.value = false;
  isLoading.value = false;
  
  // Restore body scroll
  document.body.style.overflow = 'auto';
  
  // Force cleanup
  setTimeout(() => {
    if (videoPlayer.value) {
      videoPlayer.value.src = '';
      videoPlayer.value.load();
    }
  }, 100);
};

const generateUltraCleanEmbedUrl = (videoId) => {
  const params = new URLSearchParams({
    'autoplay': '1',
    'rel': '0',
    'modestbranding': '1',
    'controls': '0',
    'showinfo': '0',
    'iv_load_policy': '3',
    'fs': '0',
    'disablekb': '1',
    'playsinline': '1',
    'enablejsapi': '1',
    'origin': window.location.origin,
    'widget_referrer': window.location.origin,
    'cc_load_policy': '0',
    'color': 'white',
    'hl': 'en',
    'cc_lang_pref': 'en',
    'version': '3',
    'loop': '0',
    'playlist': videoId,
    'mute': '0',
    'start': '0',
    'end': '0'
  });
  
  return `https://www.youtube-nocookie.com/embed/${videoId}?${params.toString()}`;
};

const getDirectVideoStream = async (videoId) => {
  try {
    console.log('🔍 Getting direct video stream for:', videoId);
    
    try {
      const response = await fetch(`/api/youtube-direct-stream?videoId=${videoId}`);
      const data = await response.json();
      
      if (data.success && data.directUrl) {
        console.log('✅ Got direct video stream from API:', data.directUrl);
        return data.directUrl;
      }
    } catch (apiError) {
      console.log('❌ API method failed, trying proxy...');
    }
    
    const proxyUrl = `/api/video-proxy/${videoId}`;
    console.log('🔄 Using proxy URL:', proxyUrl);
    
    try {
      const testResponse = await fetch(proxyUrl, { method: 'HEAD' });
      if (testResponse.ok) {
        console.log('✅ Proxy URL is accessible');
        return proxyUrl;
      }
    } catch (proxyError) {
      console.log('❌ Proxy URL not accessible');
    }
    
    console.log('🔄 Falling back to ultra-clean embed');
    return null;
    
  } catch (error) {
    console.error('❌ Error getting direct video stream:', error);
    return null;
  }
};

// Event handlers
const handleLanguageChange = async (event) => {
  iconRenderKey.value++;
  await nextTick();
};

const handleThemeChange = (event) => {
  currentTheme.value = event.detail.theme;
};

// Lifecycle
onMounted(() => {
  console.log('🎯 Instructor Details Component Mounted');
  console.log('📊 Full instructor data:', props.instructor);
  console.log('🖼️ Profile picture field:', props.instructor?.profile_picture);
  console.log('🔍 All instructor props:', Object.keys(props.instructor));
  
  // Check if profile_picture exists and its value
  if (props.instructor?.profile_picture) {
    console.log('✅ Profile picture path:', props.instructor.profile_picture);
    console.log('🔗 Constructed URL:', profilePictureUrl.value);
  } else {
    console.log('❌ No profile picture found in props');
  }
  
  const savedTheme = localStorage.getItem('preferredTheme');
  currentTheme.value = savedTheme || 'light';
  
  window.addEventListener('languageChanged', handleLanguageChange);
  window.addEventListener('themeChanged', handleThemeChange);

  const handleKeyDown = (event) => {
    if (event.key === 'Escape' && showVideoPlayer.value) {
      closeVideoPlayer();
    }
  };
  
  window.addEventListener('keydown', handleKeyDown);
});

onUnmounted(() => {
  window.removeEventListener('languageChanged', handleLanguageChange);
  window.removeEventListener('themeChanged', handleThemeChange);
});
</script>

<style scoped>
/* ==================== */
/* CRITICAL ICON FIXES */
/* ==================== */

/* Force Font Awesome icons to always display properly */
.fas, .fab, .far {
  display: inline-block !important;
  font-family: 'Font Awesome 6 Free' !important;
  font-weight: 900 !important;
  font-style: normal !important;
  font-variant: normal !important;
  text-rendering: auto !important;
  line-height: 1 !important;
  -webkit-font-smoothing: antialiased !important;
  -moz-osx-font-smoothing: grayscale !important;
}

/* Ensure icons don't disappear during language changes */
.fa-star,
.fa-book-open,
.fa-users,
.fa-video,
.fa-user-graduate,
.fa-language,
.fa-clock,
.fa-envelope,
.fa-phone,
.fa-graduation-cap,
.fa-play,
.fa-video-slash,
.fa-filter,
.fa-info-circle,
.fa-clock,
.fa-calendar,
.fa-book,
.fa-graduation-cap,
.fa-users,
.fa-facebook-f,
.fa-twitter,
.fa-instagram,
.fa-linkedin-in,
.fa-youtube,
.fa-times,
.fa-exclamation-triangle {
  font-family: 'Font Awesome 6 Free' !important;
  font-weight: 900 !important;
}

/* Fix for Font Awesome Brands */
.fab {
  font-family: 'Font Awesome 6 Brands' !important;
  font-weight: 400 !important;
}

/* Fix for Font Awesome Regular */
.far {
  font-family: 'Font Awesome 6 Free' !important;
  font-weight: 400 !important;
}

/* ==================== */
/* CSS VARIABLES FOR THEMING */
/* ==================== */
:root {
  /* Light Theme */
  --bg-primary: #ffffff;
  --bg-secondary: #f8fafc;
  --bg-tertiary: #f1f5f9;
  --card-bg: #ffffff;
  --text-primary: #1e293b;
  --text-secondary: #475569;
  --text-muted: #64748b;
  --border-color: #e2e8f0;
  --primary-color: #3b82f6;
  --primary-hover: #2563eb;
  --success-color: #10b981;
  --warning-color: #f59e0b;
  --error-color: #ef4444;
  --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
}

/* Dark Theme */
.dark {
  --bg-primary: #0f172a;
  --bg-secondary: #1e293b;
  --bg-tertiary: #334155;
  --card-bg: #1e293b;
  --text-primary: #f1f5f9;
  --text-secondary: #cbd5e1;
  --text-muted: #94a3b8;
  --border-color: #334155;
  --primary-color: #60a5fa;
  --primary-hover: #3b82f6;
  --success-color: #34d399;
  --warning-color: #fbbf24;
  --error-color: #f87171;
  --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.3), 0 1px 2px 0 rgba(0, 0, 0, 0.2);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.3), 0 4px 6px -2px rgba(0, 0, 0, 0.2);
}

/* ==================== */
/* MAIN LAYOUT */
/* ==================== */
.main-area {
  background: var(--bg-primary);
  transition: background-color 0.3s ease;
  min-height: 100vh;
}

.fix {
  position: relative;
}

/* ==================== */
/* INSTRUCTOR DETAILS AREA */
/* ==================== */
.instructor__details-area {
  background: var(--bg-primary);
  padding: 80px 0;
  transition: background-color 0.3s ease;
}

.section-pt-120 {
  padding-top: 120px;
}

.section-pb-90 {
  padding-bottom: 90px;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 15px;
}

.row {
  display: flex;
  flex-wrap: wrap;
  margin: 0 -15px;
}

.col-xl-4 {
  flex: 0 0 33.333333%;
  max-width: 33.333333%;
  padding: 0 15px;
}

.col-xl-8 {
  flex: 0 0 66.666667%;
  max-width: 66.666667%;
  padding: 0 15px;
}

.col-lg-5 {
  flex: 0 0 41.666667%;
  max-width: 41.666667%;
  padding: 0 15px;
}

.col-lg-7 {
  flex: 0 0 58.333333%;
  max-width: 58.333333%;
  padding: 0 15px;
}

/* ==================== */
/* SIDEBAR STYLES */
/* ==================== */
.instructor__sidebar {
  position: sticky;
  top: 100px;
}

.sidebar-card {
  background: var(--card-bg);
  padding: 30px;
  border-radius: 15px;
  box-shadow: var(--shadow);
  margin-bottom: 25px;
  border: 1px solid var(--border-color);
  transition: all 0.3s ease;
}

.sidebar-card:hover {
  box-shadow: var(--shadow-lg);
}

.sidebar-card .title {
  font-size: 18px;
  font-weight: 700;
  color: var(--text-primary);
  margin-bottom: 20px;
  padding-bottom: 15px;
  border-bottom: 2px solid var(--border-color);
  transition: all 0.3s ease;
}

/* ==================== */
/* PROFILE CARD STYLES */
/* ==================== */
.profile-card {
  text-align: center;
}

.profile-header {
  margin-bottom: 30px;
}

.profile-avatar {
  position: relative;
  width: 210px;
  height: 180px;
  margin: 0 auto 30px;
  border-radius: 20px;
  overflow: hidden;
}

.profile-picture {
  width: 100%;
  height: 100%;
  border-radius: 20px;
  object-fit: cover;
  border: 6px solid var(--bg-secondary);
  transition: all 0.3s ease;
  box-shadow: var(--shadow);
}

.profile-upload-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  border-radius: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: white;
  opacity: 0;
  transition: opacity 0.3s ease;
  cursor: pointer;
}

.profile-upload-overlay:hover {
  opacity: 1;
}

.profile-upload-overlay i {
  font-size: 36px;
  margin-bottom: 8px;
}

.profile-upload-overlay span {
  font-size: 14px;
  text-align: center;
}

.profile-info {
  width: 100%;
}

.profile-info .title {
  font-size: 28px;
  font-weight: 700;
  color: var(--text-primary);
  margin-bottom: 5px;
  border-bottom: none;
  padding-bottom: 0;
  transition: color 0.3s ease;
}

.designation {
  color: var(--primary-color);
  font-weight: 600;
  font-size: 18px;
  display: block;
  margin-bottom: 10px;
  transition: color 0.3s ease;
}

.rating {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  color: var(--text-muted);
  font-size: 16px;
  transition: color 0.3s ease;
}

.rating i {
  color: var(--warning-color);
}

/* ==================== */
/* PROFILE STATS */
/* ==================== */
.profile-stats {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 15px;
  margin-bottom: 25px;
}

.stat-item {
  text-align: center;
  padding: 15px;
  background: var(--bg-secondary);
  border-radius: 10px;
  transition: background-color 0.3s ease;
}

.stat-item:hover {
  background: var(--bg-tertiary);
}

.stat-icon {
  width: 40px;
  height: 40px;
  background: var(--primary-color);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 10px;
  color: #ffffff;
  transition: background-color 0.3s ease;
}

.stat-number {
  display: block;
  font-size: 18px;
  font-weight: 700;
  color: var(--text-primary);
  margin-bottom: 5px;
  transition: color 0.3s ease;
}

.stat-label {
  font-size: 12px;
  color: var(--text-muted);
  transition: color 0.3s ease;
}

/* ==================== */
/* PROFILE DETAILS */
/* ==================== */
.profile-details {
  margin-bottom: 20px;
}

.detail-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 0;
  border-bottom: 1px solid var(--border-color);
  transition: border-color 0.3s ease;
}

.detail-item:last-child {
  border-bottom: none;
}

.detail-item label {
  display: flex;
  align-items: center;
  gap: 8px;
  color: var(--text-muted);
  font-weight: 500;
  font-size: 14px;
  transition: color 0.3s ease;
}

.detail-item span {
  color: var(--text-primary);
  font-weight: 600;
  font-size: 14px;
  text-align: right;
  transition: color 0.3s ease;
}

.detail-item a {
  color: var(--text-primary);
  text-decoration: none;
  transition: color 0.3s ease;
}

.detail-item a:hover {
  color: var(--primary-color);
}

/* ==================== */
/* PROFILE BIO */
/* ==================== */
.profile-bio {
  margin-bottom: 20px;
  padding: 15px;
  background: var(--bg-secondary);
  border-radius: 10px;
  transition: background-color 0.3s ease;
}

.profile-bio p {
  color: var(--text-muted);
  line-height: 1.6;
  margin: 0;
  font-size: 14px;
  transition: color 0.3s ease;
}

/* ==================== */
/* PROFILE SOCIAL */
/* ==================== */
.profile-social {
  text-align: center;
}

.profile-social h5 {
  font-size: 16px;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 15px;
  transition: color 0.3s ease;
}

.profile-social .list-wrap {
  display: flex;
  justify-content: center;
  gap: 12px;
  list-style: none;
  padding: 0;
  margin: 0;
}

.profile-social .list-wrap li a {
  width: 40px;
  height: 40px;
  background: var(--bg-secondary);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-muted);
  text-decoration: none;
  transition: all 0.3s ease;
}

.profile-social .list-wrap li a:hover {
  background: var(--primary-color);
  color: #ffffff;
  transform: translateY(-3px);
}

/* ==================== */
/* EXPERIENCE CARD */
/* ==================== */
.experience-timeline {
  position: relative;
  padding-left: 30px;
}

.experience-item {
  position: relative;
  margin-bottom: 20px;
}

.exp-period {
  background: var(--primary-color);
  color: white;
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
  display: inline-block;
  margin-bottom: 10px;
}

.exp-dot {
  position: absolute;
  left: -38px;
  top: 5px;
  width: 12px;
  height: 12px;
  background: var(--primary-color);
  border-radius: 50%;
  border: 3px solid var(--bg-primary);
}

.exp-dot::before {
  content: '';
  position: absolute;
  left: -24px;
  top: 50%;
  transform: translateY(-50%);
  width: 20px;
  height: 2px;
  background: var(--primary-color);
}

.exp-content h6 {
  font-size: 16px;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 5px;
  transition: color 0.3s ease;
}

.exp-company {
  color: var(--primary-color);
  font-weight: 500;
  font-size: 14px;
  margin-bottom: 5px;
  transition: color 0.3s ease;
}

.exp-description {
  color: var(--text-muted);
  font-size: 13px;
  line-height: 1.5;
  margin: 0;
  transition: color 0.3s ease;
}

/* ==================== */
/* EDUCATION CARD */
/* ==================== */
.education-list {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.education-item {
  display: flex;
  align-items: flex-start;
  gap: 15px;
  padding: 15px;
  background: var(--bg-secondary);
  border-radius: 10px;
  transition: background-color 0.3s ease;
}

.education-item:hover {
  background: var(--bg-tertiary);
}

.edu-icon {
  width: 40px;
  height: 40px;
  background: var(--primary-color);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  flex-shrink: 0;
  transition: background-color 0.3s ease;
}

.edu-content h6 {
  font-size: 16px;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 5px;
  transition: color 0.3s ease;
}

.edu-institution {
  color: var(--primary-color);
  font-weight: 500;
  font-size: 14px;
  margin-bottom: 5px;
  transition: color 0.3s ease;
}

.edu-year {
  color: var(--text-muted);
  font-size: 13px;
  margin: 0;
  transition: color 0.3s ease;
}

/* ==================== */
/* MAIN CONTENT WRAPPER */
/* ==================== */
.instructor__details-wrap {
  display: flex;
  flex-direction: column;
  gap: 30px;
}

/* ==================== */
/* MAIN CONTENT SECTIONS */
/* ==================== */
.demo-videos-section,
.classes-section,
.instructor__details-biography {
  background: var(--card-bg);
  padding: 40px;
  border-radius: 20px;
  box-shadow: var(--shadow);
  border: 1px solid var(--border-color);
  transition: all 0.3s ease;
}

.demo-videos-section:hover,
.classes-section:hover,
.instructor__details-biography:hover {
  box-shadow: var(--shadow-lg);
}

.section-header {
  margin-bottom: 30px;
  text-align: center;
}

.section-header .main-title {
  font-size: 28px;
  font-weight: 700;
  color: var(--text-primary);
  margin-bottom: 10px;
  transition: color 0.3s ease;
}

.section-header p {
  color: var(--text-muted);
  margin-bottom: 0;
  font-size: 16px;
  transition: color 0.3s ease;
}

/* ==================== */
/* VIDEO CATEGORIES NAVIGATION */
/* ==================== */
.video-categories-nav {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 30px;
  padding-bottom: 20px;
  border-bottom: 1px solid var(--border-color);
  transition: border-color 0.3s ease;
}

.category-btn {
  padding: 10px 20px;
  border: 2px solid var(--border-color);
  border-radius: 25px;
  background: var(--card-bg);
  color: var(--text-muted);
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 14px;
}

.category-btn:hover {
  background: var(--primary-color);
  border-color: var(--primary-color);
  color: #ffffff;
  transform: translateY(-2px);
}

.category-btn.active {
  background: var(--primary-color);
  border-color: var(--primary-color);
  color: #ffffff;
}

/* ==================== */
/* INTRO VIDEO SECTION */
/* ==================== */
.intro-video-section {
  margin-bottom: 40px;
  padding-bottom: 30px;
  border-bottom: 2px solid var(--border-color);
  transition: border-color 0.3s ease;
}

.section-subtitle {
  font-size: 20px;
  font-weight: 700;
  color: var(--text-primary);
  margin-bottom: 20px;
  padding-bottom: 10px;
  border-bottom: 2px solid var(--primary-color);
  display: inline-block;
  transition: color 0.3s ease;
}

.intro-video-card {
  display: grid;
  grid-template-columns: 400px 1fr;
  gap: 30px;
  background: var(--bg-secondary);
  border-radius: 15px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: var(--shadow);
  border: 1px solid var(--border-color);
}

.intro-video-card:hover {
  transform: translateY(-5px);
  box-shadow: var(--shadow-lg);
}

.intro-video-thumbnail {
  position: relative;
  overflow: hidden;
  height: 250px;
}

.intro-video-thumbnail img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s ease;
}

.intro-video-card:hover .intro-video-thumbnail img {
  transform: scale(1.05);
}

.video-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.3);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.3s ease;
}

.intro-video-card:hover .video-overlay {
  opacity: 1;
}

.play-button {
  width: 60px;
  height: 60px;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--primary-color);
  font-size: 20px;
  transition: all 0.3s ease;
}

.intro-video-card:hover .play-button {
  background: #ffffff;
  transform: scale(1.1);
}

.video-duration {
  position: absolute;
  bottom: 15px;
  right: 15px;
  background: rgba(0, 0, 0, 0.7);
  color: #ffffff;
  padding: 5px 10px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
}

.video-badge {
  position: absolute;
  top: 15px;
  left: 15px;
  background: var(--error-color);
  color: white;
  padding: 5px 10px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: bold;
}

.intro-video-content {
  padding: 25px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.intro-video-content .video-title {
  font-size: 22px;
  font-weight: 700;
  color: var(--text-primary);
  margin-bottom: 15px;
  line-height: 1.3;
  transition: color 0.3s ease;
}

.intro-video-content .video-description {
  font-size: 16px;
  line-height: 1.6;
  color: var(--text-muted);
  margin-bottom: 20px;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  line-clamp: 3;
  box-orient: vertical;
  transition: color 0.3s ease;
}

.video-stats-simple {
  display: flex;
  gap: 15px;
  font-size: 13px;
  color: var(--text-muted);
  flex-wrap: wrap;
}

.video-stats-simple span {
  display: flex;
  align-items: center;
  gap: 5px;
}

.video-class {
  background: var(--bg-tertiary);
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 11px;
  color: var(--text-primary);
}

/* ==================== */
/* CLASS VIDEOS SECTIONS - HORIZONTAL LAYOUT */
/* ==================== */
.class-videos-sections {
  display: flex;
  flex-direction: column;
  gap: 40px;
}

.class-videos-section {
  margin-bottom: 30px;
}

.class-videos-horizontal {
  display: flex;
  gap: 20px;
  overflow-x: auto;
  padding: 10px 5px 20px;
  scrollbar-width: thin;
  scrollbar-color: var(--primary-color) var(--bg-secondary);
}

.class-videos-horizontal::-webkit-scrollbar {
  height: 8px;
}

.class-videos-horizontal::-webkit-scrollbar-track {
  background: var(--bg-secondary);
  border-radius: 10px;
}

.class-videos-horizontal::-webkit-scrollbar-thumb {
  background: var(--primary-color);
  border-radius: 10px;
}

.class-videos-horizontal::-webkit-scrollbar-thumb:hover {
  background: var(--primary-hover);
}

/* ==================== */
/* HORIZONTAL VIDEO CARDS */
/* ==================== */
.video-card-horizontal {
  flex: 0 0 280px;
  background: var(--card-bg);
  border-radius: 12px;
  overflow: hidden;
  box-shadow: var(--shadow);
  transition: all 0.3s ease;
  cursor: pointer;
  position: relative;
  border: 1px solid var(--border-color);
}

.video-card-horizontal:hover {
  transform: translateY(-3px);
  box-shadow: var(--shadow-lg);
}

.video-thumbnail-horizontal {
  position: relative;
  overflow: hidden;
  height: 160px;
}

.video-thumbnail-horizontal img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s ease;
}

.video-card-horizontal:hover .video-thumbnail-horizontal img {
  transform: scale(1.1);
}

.video-overlay-horizontal {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.3);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.3s ease;
}

.video-card-horizontal:hover .video-overlay-horizontal {
  opacity: 1;
}

.play-button-horizontal {
  width: 45px;
  height: 45px;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--primary-color);
  font-size: 16px;
  transition: all 0.3s ease;
}

.video-card-horizontal:hover .play-button-horizontal {
  background: #ffffff;
  transform: scale(1.1);
}

.video-duration-horizontal {
  position: absolute;
  bottom: 8px;
  right: 8px;
  background: rgba(0, 0, 0, 0.7);
  color: #ffffff;
  padding: 3px 6px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 500;
  z-index: 2;
}

.video-badge-horizontal {
  position: absolute;
  top: 8px;
  left: 8px;
  background: var(--error-color);
  color: white;
  padding: 3px 6px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: bold;
  z-index: 2;
}

.video-content-horizontal {
  padding: 15px;
}

.video-title-horizontal {
  font-size: 14px;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 8px;
  line-height: 1.3;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  line-clamp: 2;
  box-orient: vertical;
  transition: color 0.3s ease;
}

.video-meta-simple {
  display: flex;
  gap: 12px;
  font-size: 11px;
  color: var(--text-muted);
  transition: color 0.3s ease;
}

.video-meta-simple span {
  display: flex;
  align-items: center;
  gap: 4px;
}

.video-class-simple {
  background: var(--bg-tertiary);
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 10px;
  color: var(--text-primary);
}

/* ==================== */
/* CLASSES GRID */
/* ==================== */
.classes-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 20px;
  margin-top: 20px;
}

.class-card {
  background: var(--bg-secondary);
  border-radius: 12px;
  padding: 20px;
  border-left: 4px solid var(--primary-color);
  transition: all 0.3s ease;
  border: 1px solid var(--border-color);
}

.class-card:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow);
}

.class-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 15px;
}

.class-name {
  font-size: 16px;
  font-weight: 600;
  color: var(--text-primary);
  margin: 0;
  flex: 1;
  margin-right: 10px;
  transition: color 0.3s ease;
}

.class-status {
  padding: 4px 8px;
  border-radius: 12px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
}

.class-status.active {
  background: color-mix(in srgb, var(--success-color) 20%, transparent);
  color: color-mix(in srgb, var(--success-color) 70%, black);
}

.class-details {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 15px;
}

.class-subject,
.class-grade,
.class-students {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  color: var(--text-muted);
  transition: color 0.3s ease;
}

.class-subject i,
.class-grade i,
.class-students i {
  width: 14px;
  color: var(--primary-color);
}

.class-description {
  color: var(--text-secondary);
  font-size: 14px;
  line-height: 1.5;
  margin-bottom: 15px;
  transition: color 0.3s ease;
}

.class-actions {
  display: flex;
  justify-content: flex-end;
}

/* ==================== */
/* TEACHING PHILOSOPHY */
/* ==================== */
.instructor__details-biography {
  background: var(--card-bg);
  padding: 40px;
  border-radius: 20px;
  box-shadow: var(--shadow);
  border: 1px solid var(--border-color);
  transition: all 0.3s ease;
}

.instructor__details-biography .title {
  font-size: 24px;
  font-weight: 700;
  color: var(--text-primary);
  margin-bottom: 20px;
  padding-bottom: 15px;
  border-bottom: 2px solid var(--primary-color);
  transition: color 0.3s ease;
}

.instructor__details-biography p {
  color: var(--text-muted);
  line-height: 1.7;
  font-size: 16px;
  margin: 0;
  transition: color 0.3s ease;
}

/* ==================== */
/* BUTTON STYLES */
/* ==================== */
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 10px 20px;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  text-decoration: none;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 14px;
}

.btn-primary {
  background: var(--primary-color);
  color: #ffffff;
}

.btn-primary:hover {
  background: var(--primary-hover);
  transform: translateY(-2px);
  box-shadow: 0 5px 15px color-mix(in srgb, var(--primary-color) 30%, transparent);
}

.btn-sm {
  padding: 8px 16px;
  font-size: 12px;
}

.btn-outline {
  background: transparent;
  border: 2px solid var(--primary-color);
  color: var(--primary-color);
}

.btn-outline:hover {
  background: var(--primary-color);
  color: #ffffff;
}

/* ==================== */
/* TEXT UTILITIES */
/* ==================== */
.text-gray-400 { color: var(--text-muted); }
.text-gray-500 { color: var(--text-muted); }
.text-gray-600 { color: var(--text-secondary); }

.py-8 { padding-top: 2rem; padding-bottom: 2rem; }
.mb-4 { margin-bottom: 1rem; }
.mt-5 { margin-top: 1.25rem; }

.text-center { text-align: center; }

/* ==================== */
/* VIDEO PLAYER MODAL - PROPER LAYOUT */
/* ==================== */
.video-player-modal {
  background: rgba(0, 0, 0, 0.95) !important;
  z-index: 9999 !important;
  position: fixed !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
}

/* Main modal container */
.video-player-modal > div {
  z-index: 10000 !important;
  position: relative;
  height: 90vh;
  display: flex;
  flex-direction: column;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.8);
  background: #000 !important;
  border: 1px solid #333;
}

/* Header Section - 20% */
.header-section {
  height: 20%;
  min-height: 80px;
  max-height: 120px;
  display: flex;
  align-items: center;
  padding: 1.5rem;
  background: #1a1a1a !important;
  border-bottom: 1px solid #333;
}

.header-section h3 {
  font-size: 1.5rem;
  font-weight: 700;
  margin-bottom: 0.5rem;
  color: #fff !important;
}

/* Video Player Section - 70% */
.video-player-section {
  height: 70%;
  min-height: 300px;
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 !important;
  position: relative;
  background: #000 !important;
}

.video-player-section > div {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #000 !important;
}

/* Ensure video/iframe fills the entire player section */
.video-player-section iframe,
.video-player-section video {
  width: 100% !important;
  height: 100% !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain;
  background: #000 !important;
  border: none !important;
  outline: none !important;
}


.video-player-section::before,
.video-player-section::after {
  display: none !important;
}
/* Footer Section - 10% */
.footer-section {
  height: 10%;
  min-height: 60px;
  max-height: 80px;
  display: flex;
  align-items: center;
  padding: 1rem 1.5rem;
  background: #1a1a1a !important;
  border-top: 1px solid #333;
}

/* YouTube iframe container */
.youtube-isolation-fix {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;
  background: #000 !important;
  transform: none !important;
  z-index: 1 !important;
}

/* Loading overlay */
.video-player-section .absolute.inset-0 {
  z-index: 10 !important;
  background: rgba(0, 0, 0, 0.9);
}

/* Error state */
.video-player-section .flex.items-center.justify-center {
  z-index: 10 !important;
  background: rgba(0, 0, 0, 0.95);
}

/* Close button enhancements */
.video-player-modal button[aria-label="Close video player"] {
  z-index: 10020 !important;
  position: relative;
  transition: all 0.3s ease;
}

.video-player-modal button[aria-label="Close video player"]:hover {
  transform: scale(1.1);
}

/* ==================== */
/* PROFILE PICTURE UPLOAD MODAL */
/* ==================== */
.fixed {
  position: fixed;
}

.inset-0 {
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
}

.bg-black {
  background-color: #000;
}

.bg-opacity-50 {
  --tw-bg-opacity: 0.5;
}

.flex {
  display: flex;
}

.items-center {
  align-items: center;
}

.justify-center {
  justify-content: center;
}

.p-4 {
  padding: 1rem;
}

.z-50 {
  z-index: 50;
}

.bg-white {
  background-color: #fff;
}

.rounded-lg {
  border-radius: 0.5rem;
}

.w-full {
  width: 100%;
}

.max-w-md {
  max-width: 28rem;
}

.mx-4 {
  margin-left: 1rem;
  margin-right: 1rem;
}

.px-6 {
  padding-left: 1.5rem;
  padding-right: 1.5rem;
}

.py-4 {
  padding-top: 1rem;
  padding-bottom: 1rem;
}

.border-b {
  border-bottom-width: 1px;
}

.border-gray-200 {
  --tw-border-opacity: 1;
  border-color: rgb(229 231 235 / var(--tw-border-opacity));
}

.text-lg {
  font-size: 1.125rem;
  line-height: 1.75rem;
}

.font-semibold {
  font-weight: 600;
}

.text-gray-800 {
  --tw-text-opacity: 1;
  color: rgb(31 41 55 / var(--tw-text-opacity));
}

.p-6 {
  padding: 1.5rem;
}

.border-2 {
  border-width: 2px;
}

.border-dashed {
  border-style: dashed;
}

.rounded-lg {
  border-radius: 0.5rem;
}

.text-center {
  text-align: center;
}

.cursor-pointer {
  cursor: pointer;
}

.transition-colors {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}

.hidden {
  display: none;
}

.w-12 {
  width: 3rem;
}

.h-12 {
  height: 3rem;
}

.text-gray-400 {
  --tw-text-opacity: 1;
  color: rgb(156 163 175 / var(--tw-text-opacity));
}

.mx-auto {
  margin-left: auto;
  margin-right: auto;
}

.mb-3 {
  margin-bottom: 0.75rem;
}

.text-blue-600 {
  --tw-text-opacity: 1;
  color: rgb(37 99 235 / var(--tw-text-opacity));
}

.font-medium {
  font-weight: 500;
}

.text-xs {
  font-size: 0.75rem;
  line-height: 1rem;
}

.bg-red-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 242 242 / var(--tw-bg-opacity));
}

.border-red-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 202 202 / var(--tw-border-opacity));
}

.text-sm {
  font-size: 0.875rem;
  line-height: 1.25rem;
}

.text-red-600 {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity));
}

.space-x-3 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-x-reverse: 0;
  margin-right: calc(0.75rem * var(--tw-space-x-reverse));
  margin-left: calc(0.75rem * calc(1 - var(--tw-space-x-reverse)));
}

.pt-4 {
  padding-top: 1rem;
}

.border-t {
  border-top-width: 1px;
}

.mt-4 {
  margin-top: 1rem;
}

.bg-blue-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(37 99 235 / var(--tw-bg-opacity));
}

.text-white {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity));
}

.disabled\:bg-gray-400:disabled {
  --tw-bg-opacity: 1;
  background-color: rgb(156 163 175 / var(--tw-bg-opacity));
}

.disabled\:cursor-not-allowed:disabled {
  cursor: not-allowed;
}

.animate-spin {
  animation: spin 1s linear infinite;
}

@keyframes spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

.-ml-1 {
  margin-left: -0.25rem;
}

.mr-2 {
  margin-right: 0.5rem;
}

.h-4 {
  height: 1rem;
}

.w-4 {
  width: 1rem;
}

/* ==================== */
/* LOAD MORE BUTTON */
/* ==================== */
.load-more-section {
  text-align: center;
  margin-top: 40px;
  padding-top: 30px;
  border-top: 1px solid var(--border-color);
}

/* ==================== */
/* NO CONTENT STATES */
/* ==================== */
.no-content-state {
  text-align: center;
  padding: 60px 20px;
}

.no-content-state i {
  color: var(--text-muted);
  margin-bottom: 20px;
}

.no-content-state h4 {
  color: var(--text-secondary);
  margin-bottom: 10px;
  font-size: 18px;
  font-weight: 600;
}

.no-content-state p {
  color: var(--text-muted);
  font-size: 14px;
  max-width: 400px;
  margin: 0 auto;
}

/* ==================== */
/* RESPONSIVE DESIGN */
/* ==================== */
@media (max-width: 1199px) {
  .video-card-horizontal {
    flex: 0 0 260px;
  }
  
  .intro-video-card {
    grid-template-columns: 350px 1fr;
  }
}

@media (max-width: 991px) {
  .instructor__sidebar {
    position: static;
    margin-bottom: 40px;
  }
  
  .col-xl-4,
  .col-xl-8,
  .col-lg-5,
  .col-lg-7 {
    flex: 0 0 100%;
    max-width: 100%;
  }
  
  .profile-stats {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .classes-grid {
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  }
  
  .intro-video-card {
    grid-template-columns: 1fr;
  }
  
  .intro-video-thumbnail {
    height: 200px;
  }
  
  .video-card-horizontal {
    flex: 0 0 240px;
  }
  
  .header-section {
    height: 15%;
    min-height: 70px;
    padding: 1rem;
  }
  
  .video-player-section {
    height: 75%;
    min-height: 250px;
  }
  
  .footer-section {
    height: 10%;
    min-height: 50px;
    padding: 0.75rem 1rem;
  }
}

@media (max-width: 767px) {
  .instructor__details-area {
    padding: 60px 0;
  }
  
  .demo-videos-section,
  .sidebar-card,
  .classes-section,
  .instructor__details-biography {
    padding: 25px;
  }
  
  .classes-grid {
    grid-template-columns: 1fr;
  }
  
  .video-categories-nav {
    justify-content: center;
  }
  
  .profile-stats {
    grid-template-columns: 1fr;
    gap: 10px;
  }
  
  .video-player-modal {
    padding: 10px;
  }
  
  .section-header .main-title {
    font-size: 24px;
  }
  
  .intro-video-content {
    padding: 20px;
  }
  
  .intro-video-content .video-title {
    font-size: 18px;
  }
  
  .section-subtitle {
    font-size: 18px;
  }
  
  .video-card-horizontal {
    flex: 0 0 220px;
  }
  
  .video-thumbnail-horizontal {
    height: 140px;
  }
  
  /* Adjust profile picture for mobile */
  .profile-avatar {
    width: 180px;
    height: 150px;
  }
  
  .profile-avatar img {
    width: 180px;
    height: 150px;
  }
  
  .video-player-modal > div {
    height: 95vh;
    margin: 0.5rem;
  }
}

@media (max-width: 575px) {
  .video-meta-simple {
    flex-direction: column;
    gap: 5px;
  }
  
  .detail-item {
    flex-direction: column;
    align-items: flex-start;
    gap: 5px;
  }
  
  .detail-item span {
    text-align: left;
  }
  
  .class-header {
    flex-direction: column;
    gap: 10px;
  }
  
  .class-status {
    align-self: flex-start;
  }
  
  /* Further adjust profile picture for small mobile */
  .profile-avatar {
    width: 150px;
    height: 125px;
  }
  
  .profile-avatar img {
    width: 150px;
    height: 125px;
  }
  
  .profile-info .title {
    font-size: 20px;
  }
  
  .video-info {
    padding: 20px;
  }
  
  .video-info h4 {
    font-size: 18px;
  }
  
  .video-info p {
    font-size: 14px;
  }
  
  .class-actions {
    flex-direction: column;
  }
  
  .btn-outline {
    width: 100%;
    justify-content: center;
  }
  
  .intro-video-thumbnail {
    height: 180px;
  }
  
  .intro-video-content .video-title {
    font-size: 16px;
  }
  
  .intro-video-content .video-description {
    font-size: 14px;
  }
  
  .video-card-horizontal {
    flex: 0 0 200px;
  }
  
  .video-thumbnail-horizontal {
    height: 120px;
  }
  
  .video-title-horizontal {
    font-size: 13px;
  }
  
  .video-player-modal {
    padding: 0.5rem;
  }
  
  .video-player-modal > div {
    height: 100vh;
    margin: 0;
    border-radius: 0;
  }
  
  .header-section {
    height: 15%;
    min-height: 60px;
  }
  
  .video-player-section {
    height: 75%;
  }
  
  .footer-section {
    height: 10%;
    min-height: 50px;
  }
  
  .header-section h3 {
    font-size: 1.1rem;
  }
}

/* ==================== */
/* ACCESSIBILITY */
/* ==================== */
.btn:focus,
.category-btn:focus,
.close-modal:focus {
  outline: 3px solid color-mix(in srgb, var(--primary-color) 30%, transparent);
  outline-offset: 2px;
}

/* ==================== */
/* REDUCED MOTION */
/* ==================== */
@media (prefers-reduced-motion: reduce) {
  .sidebar-card,
  .video-card-horizontal,
  .class-card,
  .intro-video-card,
  .btn,
  .category-btn,
  .close-modal {
    transition: none;
  }
  
  .video-card-horizontal:hover,
  .class-card:hover,
  .intro-video-card:hover,
  .btn:hover:not(:disabled),
  .category-btn:hover {
    transform: none;
  }
  
  .video-card-horizontal:hover .video-thumbnail-horizontal img,
  .intro-video-card:hover .intro-video-thumbnail img {
    transform: none;
  }
  
  .fadeIn,
  .slideUp {
    animation: none;
  }
}

/* ==================== */
/* SCROLLBAR STYLING */
/* ==================== */
::-webkit-scrollbar {
  width: 6px;
  height: 6px;
}

::-webkit-scrollbar-track {
  background: var(--bg-secondary);
  border-radius: 10px;
}

::-webkit-scrollbar-thumb {
  background: var(--primary-color);
  border-radius: 10px;
}

::-webkit-scrollbar-thumb:hover {
  background: var(--primary-hover);
}

/* ==================== */
/* PRINT STYLES */
/* ==================== */
@media print {
  .video-player-modal,
  .profile-upload-overlay,
  .category-btn,
  .play-button,
  .play-button-horizontal {
    display: none !important;
  }
  
  .sidebar-card,
  .demo-videos-section,
  .classes-section,
  .instructor__details-biography {
    box-shadow: none;
    border: 1px solid #000;
  }
}
</style>